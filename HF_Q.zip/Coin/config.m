global T fs dt t t1 N N1;

T = 2;
fs = 100;
dt = 1/fs;
t = 0:dt:T;
t1 = 0.04:0.04:T;
N = length(t);
N1 = length(t1);


set(0, 'DefaultTextFontName', 'Times New Roman');      % 设置所有文本的默认字体
set(0, 'DefaultTextFontSize', 14);           % 设置所有文本的默认字号
set(0, 'DefaultAxesFontName', 'Times New Roman');      % 设置坐标轴的默认字体
set(0, 'DefaultAxesFontSize', 14);           % 设置坐标轴的默认字号
set(0, 'DefaultLegendFontName', 'Times New Roman');    % 设置图例的默认字体
set(0, 'DefaultLegendFontSize', 14);         % 设置图例的默认字号