function ser_est = Ser_exp(theta,q_true,expan)
%SER_EXP 此处显示有关此函数的摘要
%   此处显示详细说明
global N;
angle_increment_matrix = zeros(3, 4);
t_coff = zeros(4, 4);
ser_est=zeros(4,(N-1)/4);
for n=1:(N-1)/4
    result=[1;0;0;0];
    start_time1=0;
    for l = 1:4
        t_sample_start = start_time1 + (l-1)*0.01;
        t_sample_end = start_time1 + l*0.01;
        for m = 1:4
            coff_temp = 4 - m + 1; % MATLAB 索引从 1 开始
            t_coff(m, l) = (t_sample_end^coff_temp - t_sample_start^coff_temp) / coff_temp;
        end
        angle_increment_matrix(:, l) = theta(:,4*n-4+l);
    end
    w = zeros(4, 4);
    t_coff_inv = inv(t_coff);
    w(2:4, :) = 0.5 * angle_increment_matrix/t_coff;
    angular_coeff=w;
    angular_coff=2*w;
    Taylor_Quaternion = {result};
    for i = 1:expan
        Q_i = Quaternion_Dot(Taylor_Quaternion, angular_coff, i);
        Taylor_Quaternion{end+1} = Q_i;
        dtq = Q_i * (0.04^i) / Factorial(i);
        result = result + dtq;
    end
    if n==1
        ser_est(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        ser_est(:,n)=quatmultiply(ser_est(:,n-1)',result')';
    end
end
end

