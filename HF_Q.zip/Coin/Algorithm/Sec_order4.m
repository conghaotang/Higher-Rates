function q_est_2s4 = Sec_order4(theta,q_true)
%SEC_ORDER4 此处显示有关此函数的摘要
%   此处显示详细说明
global N1 N;
q_est_2s4 = zeros(4, N1);
for k = 4:4:N-1
    % 提取四个子样θ1-θ4
    m=k/4;
    theta1 = theta(:,k-3);
    theta2 = theta(:,k-2);
    theta3 = theta(:,k-1);
    theta4 = theta(:,k);

    % 等效旋转矢量（式19）
    cross_terms = cross((18/35)*theta1+ (92/105)*theta2+(214/105)*theta3,theta4);
    g_4 = theta1 + theta2 + theta3 + theta4 + cross_terms;

    % 转换为四元数增量
    phi = norm(g_4);
    e = g_4 / phi;
    dq = [cos(phi/2); e*sin(phi/2)];
    % 四元数更新
    if k==4
        q_est_2s4(:,m)=quatmultiply(q_true(:,1)',dq')';
    else
        q_est_2s4(:,m)=quatmultiply(q_est_2s4(:,m-1)',dq')';
    end
end
end

