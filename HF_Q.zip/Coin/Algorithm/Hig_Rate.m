function hf_est = Hig_Rate(theta,q_true,expan)
%HIG_RATE 此处显示有关此函数的摘要
%   此处显示详细说明
global N1;
hf_est=zeros(4,N1);
Y=zeros(3,4);
G=zeros(4,4);

k=2*expan;
for n=1:N1
    start_time=0;
    for l=1:4
        t_sample_start = start_time + (l-1)*0.01;
        t_sample_end = start_time + l*0.01;
        for m = 1:4
            G(m, l) = (t_sample_end^m - t_sample_start^m);
        end
        Y(:,l)=theta(:,4*n-4+l);
    end
    A=Y*inv(G);
    for  l=1:k
        t_resample_start = start_time + (l-1)*0.04/k;
        t_resample_end = start_time + l*0.04/k;
        for m=1:4
            H(m,l) = (t_resample_end^m - t_resample_start^m);
        end
    end
    theta_resample = A*H;
    result=[1;0;0;0];
    for i=2:2:k
        % 提取相邻两个子样（假设采样间隔为dt）
        theta1 = theta_resample(:,i-1);
        theta2 = theta_resample(:,i);
        % 等效旋转矢量（式13）
        g_12 = theta1 + theta2 + (2/3)*cross(theta1, theta2);
        % 转换为四元数增量（式14）
        phi12 = norm(g_12);
        e12 = g_12 / phi12;
        dq12 = [cos(phi12/2); e12*sin(phi12/2)];
        result= quatmultiply(result',dq12')';
    end

    if n==1
        hf_est(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        hf_est(:,n)=quatmultiply(hf_est(:,n-1)',result')';
    end
end

