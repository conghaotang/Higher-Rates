function q_est_2s = Sec_order(theta,q_true)
%SEC_ORDER 此处显示有关此函数的摘要
%   此处显示详细说明
global N1 N;
q_est_2s = zeros(4,N1);
q_est_2s = q_true(:,1); % 初始姿态
for k = 2:2:(N-1)/2
    % 提取相邻两个子样（假设采样间隔为dt）
    theta1 = theta(:,2*k-3);
    theta2 = theta(:,2*k-2);
    theta3 = theta(:,2*k-1);
    theta4 = theta(:,2*k);
    % 等效旋转矢量（式13）
    g_12 = theta1 + theta2 + (2/3)*cross(theta1, theta2);
    g_34 = theta3 + theta4 + (2/3)*cross(theta3, theta4);
    % 转换为四元数增量（式14）
    phi12 = norm(g_12);
    phi34 = norm(g_34);
    e12 = g_12 / phi12;
    e34 = g_34 / phi34;
    dq12 = [cos(phi12/2); e12*sin(phi12/2)];
    dq12=dq12/norm(dq12);
    dq34 = [cos(phi34/2); e34*sin(phi34/2)];
    dq34=dq34/norm(dq34);
    zl=quatmultiply(dq12',dq34')';
    % 四元数更新（式17-18）
    if k==2
        q_est_2s(:,k/2)=quatmultiply(q_true(:,1)',zl')';
    else
        q_est_2s(:,k/2)=quatmultiply(q_est_2s(:,k/2-1)',zl')';
    end
end
end

