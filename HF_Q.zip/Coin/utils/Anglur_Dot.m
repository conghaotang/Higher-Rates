function result = Anglur_Dot(n)
    result=zeros(4,1);
    if n>=4
        result=result;
    else
        result(4-n,1)= Factorial(n);
    end
end
