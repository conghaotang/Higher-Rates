function g_dot = Gibbs_Dot2(anglur, Gibbs)
    % 计算Gibbs导数
    g_dot = 0.5 * anglur + 0.5 * cross(Gibbs, anglur) + 0.5 * Gibbs * (Gibbs' * anglur);
end