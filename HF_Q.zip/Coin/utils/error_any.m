function error = error_any(q_est,q_true)
%ERROR_ANY 此处显示有关此函数的摘要
%   此处显示详细说明
global N;
error = zeros(1, (N-1)/4);
for k = 1:(N-1)/4
    delta_q = quatmultiply(q_true(:,4*k+1)', quatconj(q_est(:,k)'));
    error(k) = 2 * abs(atan2(norm(delta_q(2:4)), delta_q(1)))*180/pi;
end
end

