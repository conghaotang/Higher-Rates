function gibbs_dot = Gibbs_Dot(coin_angle,coin_anglur)
%GIBBS_DOT 此处显示有关此函数的摘要
%   此处显示详细说明
global t;
gibbs_dot = zeros(3, length(t));
for i = 1:length(t)
    gibbs_dot(:, i) = [0;
        -coin_anglur * tan(coin_angle / 2) * sin(coin_anglur * t(i));
        coin_anglur * tan(coin_angle / 2) * cos(coin_anglur * t(i))];
end
end

