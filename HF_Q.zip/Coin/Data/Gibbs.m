function gibbs = Gibbs(coin_angle,coin_anglur)
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
global t;
 gibbs   = zeros(3, length(t));
for i = 1:length(t)
    gibbs(:, i) = [0;
        tan(coin_angle/2)*cos(coin_anglur*t(i));
        tan(coin_angle/2)*sin(coin_anglur*t(i))];
end
end

