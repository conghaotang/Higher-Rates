function [gibbs,gibbs_dot,omega, theta, q_true] = trj(coin_angle,coin_anglur)
%TRJ 计算并将变量保存到自定义路径（只需修改save_path变量即可）
%   输入：coin_angle(硬币角度), coin_anglur(硬币角速度)
%   输出：gibbs/gibbs_dot/omega/theta/q_true

config;

% 核心计算逻辑
gibbs=Gibbs(coin_angle,coin_anglur);
gibbs_dot = Gibbs_Dot(coin_angle,coin_anglur);
omega = Omega(gibbs,gibbs_dot);
theta = Angle_Increment(coin_angle,coin_anglur);
q_true = Q_true(gibbs);

% ========== 关键：自定义保存路径（只需改这里！） ==========
% 1. 直接指定绝对路径（推荐，最稳定）
% 示例（Windows）：save_path = 'D:\我的项目\调用函数的文件夹';
% 示例（Mac/Linux）：save_path = '/Users/我的项目/调用函数的文件夹';
% 示例（当前文件夹）：save_path = pwd; % 等同于MATLAB当前工作目录
save_path = 'D:\GInav\HF\Coin\coin_data'; % 替换成你实际的路径！

% 2. 检查路径是否存在，不存在则自动创建（避免路径错误）
if ~exist(save_path, 'dir')
    mkdir(save_path); % 自动创建文件夹
    disp(['已创建保存文件夹：', save_path]);
end

% ========== 分类保存（无需修改，路径由save_path控制） ==========
save(fullfile(save_path, 'gibbs.mat'), 'gibbs', 'gibbs_dot');
save(fullfile(save_path, 'omega.mat'), 'omega');
save(fullfile(save_path, 'theta.mat'), 'theta');
save(fullfile(save_path, 'q_true.mat'), 'q_true');

% 可选：打印保存路径，验证是否正确
disp(['数据已保存到：', save_path]);

end