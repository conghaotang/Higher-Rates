

clear;
clc;
coin_angle=10*pi/180;
coin_anglur = 6*pi;

trj(coin_angle,coin_anglur);