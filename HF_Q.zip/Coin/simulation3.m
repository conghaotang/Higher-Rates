T = 2;
fs = 100;
dt = 1/fs;
t = 0:dt:T;
t1 = 0.04:0.04:T;
N = length(t);
N1 = length(t1);
% 定义需要测试的coin值
coin_values = [0.1, 0.5, 1, 5, 10, 45, 90];

% 定义各算法的迭代次数
fun_iterations = [3, 6, 9, 12];  % Fun_iter函数的迭代次数
ser_iterations = [3, 6, 9, 12];  % Ser_exp函数的迭代次数
hf_iterations = [2, 4, 8, 16];    % Hig_Rate函数的迭代次数

% ========== 新增：稳定计时配置 ==========
repeat_times = 20;  % 重复运行次数（建议10-50次，可根据需求调整）
maxNumCompThreads(1); % 固定单线程运行，减少线程调度干扰

% 计算总结果矩阵大小：coin值数量 × (三个算法×各自迭代次数)
total_cols = length(fun_iterations) + length(ser_iterations) + length(hf_iterations);
results = zeros(length(coin_values), total_cols);

% 用于存储计算时间（改为存储每次重复的时间，后续取平均）
fun_time_raw = zeros(length(coin_values), length(fun_iterations), repeat_times);
ser_time_raw = zeros(length(coin_values), length(ser_iterations), repeat_times);
hf_time_raw = zeros(length(coin_values), length(hf_iterations), repeat_times);

% 定义线型样式（用于区分不同迭代次数）
line_styles = {'-', '--', '-.', ':'};

% 为每个迭代次数定义不同的标记，增强区分度
markers = {'o', 's', '^', 'd'};  % 圆形、方形、三角形、菱形

% ========== 新增：预热运行（消除编译缓存影响） ==========
fprintf('正在预热运行...\n');
warmup_coin = coin_values(1);
warmup_anglur = 4*pi;
warmup_gibbs = Gibbs(warmup_coin, warmup_anglur);
warmup_gibbs_dot = Gibbs_Dot(warmup_coin, warmup_anglur);
warmup_omega = Omega(warmup_gibbs, warmup_gibbs_dot);
warmup_theta = Angle_Increment(warmup_coin, warmup_anglur);
warmup_q_true = Q_true(warmup_gibbs);
% 预热各核心函数
Fun_iter(warmup_theta, warmup_q_true, fun_iterations(1));
Ser_exp(warmup_theta, warmup_q_true, ser_iterations(1));
Hig_Rate(warmup_theta, warmup_q_true, hf_iterations(1));
error_any(warmup_q_true, warmup_q_true);
fprintf('预热完成，开始正式计算...\n');

% 循环处理每个coin值
for idx = 1:length(coin_values)
    coin_angle = coin_values(idx);  % 当前coin值
    coin_anglur = 4*pi;             % 保持不变

    % 计算相关参数
    gibbs = Gibbs(coin_angle, coin_anglur);
    gibbs_dot = Gibbs_Dot(coin_angle, coin_anglur);
    omega = Omega(gibbs, gibbs_dot);
    theta = Angle_Increment(coin_angle, coin_anglur);
    q_true = Q_true(gibbs);

    % 处理Fun_iter不同迭代次数，统计时间（多次重复）
    col_idx = 1;
    for i = 1:length(fun_iterations)
        iter = fun_iterations(i);
        % 重复运行repeat_times次，记录每次耗时
        for r = 1:repeat_times
            start_time = tic;
            fun_est = Fun_iter(theta, q_true, iter);
            fun_error = error_any(fun_est, q_true);  % 先计算完整误差序列
            fun_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
        end
        % 误差只取最后一次运行的结果（或可改为mean，根据需求）
        results(idx, col_idx) = fun_error(end);  
        col_idx = col_idx + 1;
    end

    % 处理Ser_exp不同迭代次数，统计时间（多次重复）
    for i = 1:length(ser_iterations)
        iter = ser_iterations(i);
        for r = 1:repeat_times
            start_time = tic;
            ser_est = Ser_exp(theta, q_true, iter);
            ser_error = error_any(ser_est, q_true);  % 先计算完整误差序列
            ser_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
        end
        results(idx, col_idx) = ser_error(end);  % 再取最后一个元素
        col_idx = col_idx + 1;
    end

    % 处理Hig_Rate不同迭代次数，统计时间（多次重复）
    for i = 1:length(hf_iterations)
        iter = hf_iterations(i);
        for r = 1:repeat_times
            start_time = tic;
            hf_est = Hig_Rate(theta, q_true, iter);
            hf_error = error_any(hf_est, q_true);    % 先计算完整误差序列
            hf_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
        end
        results(idx, col_idx) = hf_error(end);   % 再取最后一个元素
        col_idx = col_idx + 1;
    end
    
    % 进度提示
    fprintf('已完成 %d/%d 个coin值的计算\n', idx, length(coin_values));
end

% ========== 新增：计算平均时间（消除偶然误差） ==========
% 对重复运行的时间取平均，得到稳定的计时结果
fun_time = mean(fun_time_raw, 3);  % 沿第3维（重复次数）取平均
ser_time = mean(ser_time_raw, 3);
hf_time = mean(hf_time_raw, 3);

% 计算每种迭代次数下的平均计算时间
fun_avg_time = mean(fun_time, 1);
ser_avg_time = mean(ser_time, 1);
hf_avg_time = mean(hf_time, 1);

% 打印统计结果
fprintf('Fun_iter 平均计算时间 (秒)：\n');
for i = 1:length(fun_iterations)
    fprintf('迭代次数 %d: %.6f\n', fun_iterations(i), fun_avg_time(i));
end

fprintf('\nSer_exp 平均计算时间 (秒)：\n');
for i = 1:length(ser_iterations)
    fprintf('迭代次数 %d: %.6f\n', ser_iterations(i), ser_avg_time(i));
end

fprintf('\nHig_Rate 平均计算时间 (秒)：\n');
for i = 1:length(hf_iterations)
    fprintf('迭代次数 %d: %.6f\n', hf_iterations(i), hf_avg_time(i));
end

% 创建图形
figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 11, 15]);   % Position向量：[左偏移, 下偏移, 宽度, 高度]
set(gca, 'FontSize', 14);
hold on;

algorithms = {'FI3','FI6','FI9','FI12',...
              'TS3','TS6','TS9','TS12',...
              'HR4','HR8','HR16','HR32'};

% 统一线宽设置
line_width = 1;

% 绘制Fun_iter不同迭代次数的结果（蓝色系）
color = 'b';
col_idx = 1;
for i = 1:length(fun_iterations)
    loglog(coin_values, results(:, col_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...          % 不同迭代次数使用不同标记
        'LineStyle', line_styles{i}, ...   % 不同迭代次数使用不同线型
        'LineWidth', line_width, ...       % 统一线宽
        'MarkerSize', 6, ...               % 稍大的标记尺寸
        'MarkerEdgeColor', color, ...      % 标记边缘颜色与线条一致
        'MarkerFaceColor', [0.8 0.8 1]);   % 浅蓝色填充，增强识别度
    col_idx = col_idx + 1;
end

% 绘制Ser_exp不同迭代次数的结果（红色系）
color = 'r';
for i = 1:length(ser_iterations)
    loglog(coin_values, results(:, col_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...
        'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', color, ...
        'MarkerFaceColor', [1 0.8 0.8]);   % 浅红色填充
    col_idx = col_idx + 1;
end

% 绘制Hig_Rate不同迭代次数的结果（绿色系）
color = 'g';
for i = 1:length(hf_iterations)
    loglog(coin_values, results(:, col_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...
        'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', color, ...
        'MarkerFaceColor', [0.8 1 0.8]);   % 浅绿色填充
    col_idx = col_idx + 1;
end

% 图形设置
xlabel('conic angle', 'FontSize', 14);
ylabel('Attitude errors (″)', 'FontSize', 14);
ylim([1e-8, 1e2]);  % 例如设置y轴从1e-3到1e2
grid on;
box on;
drawnow;

% 图例设置
legend_obj = legend(algorithms, 'Location', 'best');
set(legend_obj, ...
    'Box', 'off', ...                  % 去掉边框
    'FontSize', 14, ...                 % 字体大小
    'Interpreter', 'none');          % 避免特殊字符解析问题

% 坐标轴网格设置
ax = gca;
% 主网格设置
ax.YGrid = 'on';                  
ax.GridLineStyle = '--';          
ax.GridColor = [0, 0, 0];         
ax.GridLineWidth = 1;           
% 次网格设置
ax.YMinorGrid = 'on';             
ax.MinorGridLineStyle = ':';      
ax.MinorGridColor = [0.3, 0.3, 0.3]; 
ax.MinorGridLineWidth = 0.2;      

hold off;

%% 修正表头维度不匹配问题
% 1. 准备误差数据（保持不变）
error_data = [coin_values'  results];  % 7行×13列（1列圆锥角+12列误差）

% 2. 修正表头：保持algorithms为行向量，与{'conic angle'}横向拼接
error_headers = [{'conic angle'}, algorithms];  % 关键：去掉algorithms后的单引号'

% 验证表头维度（应显示 1×13，1行13列）
disp(['表头维度：', num2str(size(error_headers))]);

% 3. 时间统计数据处理（保持不变）
fun_time_data = table( ...
    repmat({'Fun_iter'}, length(fun_iterations), 1), ...
    fun_iterations', ...
    fun_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

ser_time_data = table( ...
    repmat({'Ser_exp'}, length(ser_iterations), 1), ...
    ser_iterations', ...
    ser_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

hf_time_data = table( ...
    repmat({'Hig_Rate'}, length(hf_iterations), 1), ...
    hf_iterations', ...
    hf_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

time_stats = [fun_time_data; ser_time_data; hf_time_data];

% 4. 保存到Excel
filename = 'conic_simulation3.xlsx';
writecell(error_headers, filename, 'Sheet', 1, 'Range', 'A1');
writematrix(error_data, filename, 'Sheet', 1, 'Range', 'A2');
writetable(time_stats, filename, 'Sheet', 2, 'Range', 'A1', 'WriteVariableNames', true);

disp(['数据已保存到：', fullfile(pwd, filename)]);