config;

% 定义需要测试的coin值
coin_values = [0.1, 0.5, 1, 5, 10, 60,90];

% 初始化存储结果的矩阵，每行对应一个coin值的结果
results = zeros(length(coin_values), 5);  % 5种误差结果

% 循环处理每个coin值
for idx = 1:length(coin_values)
    coin_angle = coin_values(idx);  % 当前coin值
    coin_anglur = 0.74*pi;             % 保持不变
    
    % 计算相关参数
    gibbs = Gibbs(coin_angle, coin_anglur);
    gibbs_dot = Gibbs_Dot(coin_angle, coin_anglur);
    omega = Omega(gibbs, gibbs_dot);
    theta = Angle_Increment(coin_angle, coin_anglur);
    q_true = Q_true(gibbs);
    
    % 各种算法估计
    q_est_2s = Sec_order(theta, q_true);
    q_est_2s4 = Sec_order4(theta, q_true);
    fun_est = Fun_iter(theta, q_true, 8);
    ser_est = Ser_exp(theta, q_true, 12);
    hf_est = Hig_Rate(theta, q_true, 16);
    
    % 误差分析
    q_est_2s_error = error_any(q_est_2s, q_true);
    q_est_2s4_error = error_any(q_est_2s4, q_true);
    ser_est_error = error_any(ser_est, q_true);
    fun_est_error = error_any(fun_est, q_true);
    hf_est_error = error_any(hf_est, q_true);
    
    % 存储每种误差的最后一个元素
    results(idx, 1) = q_est_2s_error(end);       % 二阶二子样最后误差
    results(idx, 2) = q_est_2s4_error(end);      % 二阶四子样最后误差
    results(idx, 3) = ser_est_error(end);        % 级数展开最后误差
    results(idx, 4) = fun_est_error(end);        % 函数迭代最后误差
    results(idx, 5) = hf_est_error(end);         % 高频输出最后误差
end

% 显示结果
algorithms = {'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};
colors = {'b', 'r', 'g', 'm', 'c'};
markers = {'o', 's', '^', 'd', '*'};

% 创建图形
figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 12, 12]);   % Position向量：[左偏移, 下偏移, 宽度, 高度]

% 绘制每种算法的误差曲线
for i = 1:5
    loglog(coin_values, results(:, i), 'Color', colors{i}, 'Marker', markers{i}, ...
         'LineWidth', 2, 'MarkerSize', 11);
    hold on;
end

% 图形设置
xlabel('conic angle','FontSize', 14);
ylabel('Attitude erroes (″)');
legend('SO2+2', 'SO4', 'TS12', 'FI12', 'HR32');
set(legend, 'Box', 'off'); % 去掉图例边框
grid on;

% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
% 主网格设置（又细又黑）
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;           % 细线宽

% 次网格设置（又细又黑，更淡一些）
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细
box on;

%% 保存圆锥角-姿态误差绘图数据到Excel
% 1. 准备数据（确保维度匹配）
% coin_values：1×7行向量（7个圆锥角），转置为7×1列向量
% results：7×5矩阵（7行=7个圆锥角，5列=5种算法误差）
% 横向拼接后得到 7×6 矩阵（第一列=圆锥角，后5列=各算法误差）
save_data = [coin_values' , results];  % 关键：coin转置为列向量，与results横向拼接

% 验证数据维度（应显示 "数据矩阵维度：7  6"，7行6列）
disp(['数据矩阵维度：', num2str(size(save_data))]);

% 2. 创建表头（与数据列一一对应）
% 第一列=圆锥角（x轴标签），后5列=5种算法名称（对应legend和algorithms变量）
headers = {'conic angle', 'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};

% 3. 保存到Excel
% 文件名：明确标识“圆锥角-姿态误差”，避免与其他文件混淆
filename = 'conic_simulation2.xlsx';

% 写入表头（从A1到F1，6列）
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1');
% 写入数据（从A2到F8，7行数据，对应7个圆锥角）
writematrix(save_data, filename, 'Sheet', 1, 'Range', 'A2');

% 提示保存路径（当前工作目录）
disp(['绘图数据已保存到：', fullfile(pwd, filename)]);