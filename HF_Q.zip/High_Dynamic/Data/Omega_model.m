%角速度模型
function omega = Omega_model(t)
o=0.48*pi;
A = 3*[1, o, -o^2/2, -o^3/6,o^4/24,o^5/120,-o^6/720,-o^7/5040;
     0, o, 0, -2*o^3/3,0,-2*o^5/15,0,-4*o^7/315;
     -1,o,o^2/2,-o^3/6,-o^4/24,o^5/120,o^6/720,-o^7/5040];
 time_vec1 = [1; t; t^2; t^3; t^4;t^5;t^6;t^7];
 g=A*time_vec1;
 dtime_vec = [0; 1; 2*t; 3*t^2;4*t^3;5*t^4;6*t^5;7*t^6];
 dg = A(1:3, :) * dtime_vec;
 norm_g = 1 + norm(g)^2;
 omega = (2 * (dg - cross(g, dg))) / norm_g;%得到角速度模

end