function theta = Angle_Increment()
%ANGLE_INCREMENT 此处显示有关此函数的摘要
%   此处显示详细说明
%% 计算角增量（采用积分法)
global N dt;
alpha = zeros(3, N-1);
for i = 1:N-1
    t_end = dt * i;
    for j = 1:3
        %定义匿名函数，利用 arrayfun 对标量积分
        fun_j = @(t) arrayfun(@(tau)getOmegaComponent(tau, j),t);
        alpha(j, i) = integral(fun_j, 0, t_end);
    end
end

theta = zeros(3, N-1);
theta(:,1) = alpha(:,1);
for i = 2:N-1
    theta(:, i) = alpha(:, i) - alpha(:, i-1) ;
end
end

