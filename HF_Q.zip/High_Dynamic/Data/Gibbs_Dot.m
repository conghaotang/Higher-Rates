function gibbs_dot = Gibbs_Dot(coin_angle,coin_anglur)
%GIBBS_DOT 此处显示有关此函数的摘要
%   此处显示详细说明
global t;
o=0.48*pi;
A = 3*[1, o, -o^2/2, -o^3/6,o^4/24,o^5/120,-o^6/720,-o^7/5040;
    0, o, 0, -2*o^3/3,0,-2*o^5/15,0,-4*o^7/315;
    -1,o,o^2/2,-o^3/6,-o^4/24,o^5/120,o^6/720,-o^7/5040];
gibbs_dot = zeros(3, length(t));
for i = 1:length(t)
    dtime_vec = [0; 1; 2*t(i); 3*t(i)^2;4*t(i)^3;5*t(i)^4;6*t(i)^5;7*t(i)^6];
    gibbs_dot(:, i) = A(1:3, :) * dtime_vec;
end
end

