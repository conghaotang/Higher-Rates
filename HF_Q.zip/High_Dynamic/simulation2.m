

config;


gibbs=Gibbs();
gibbs_dot = Gibbs_Dot();

omega = Omega(gibbs,gibbs_dot);

theta = Angle_Increment();

q_true = Q_true(gibbs);

%%二阶二子样算法
start_time = tic;
q_est_2s = Sec_order(theta,q_true);
end_time = toc(start_time)

%%二阶四子样
start_time = tic;
q_est_2s4 = Sec_order4(theta,q_true);
end_time = toc(start_time)

%%函数迭代
start_time = tic;
fun_est = Fun_iter(theta,q_true,10);
end_time = toc(start_time)

%%级数展开
start_time = tic;
ser_est = Ser_exp(theta,q_true,12);
end_time = toc(start_time)

%%高频输出
start_time = tic;
hf_est2 = Hig_Rate(theta,q_true,22);
start_time = toc(start_time)


%%误差分析
q_est_2s_error = error_any(q_est_2s,q_true);
q_est_2s4_error = error_any(q_est_2s4,q_true);
ser_est_error = error_any(ser_est,q_true);
fun_est_error = error_any(fun_est,q_true);
hf_est_error2 = error_any(hf_est2,q_true);



figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 11, 11]);   % Position向量：[左偏移, 下偏移, 宽度, 高度] 
% semilogy(t1, q_est_2s_error, 'b', 'LineWidth', 2.5); hold on;
% semilogy(t1, q_est_2s4_error, 'r', 'LineWidth', 2.5);
% %semilogy(t1, fun_est_error, 'b', 'LineWidth', 2.5);
% %semilogy(t1, ser_est_error, 'r', 'LineWidth', 2.5);
%
% semilogy(t1, hf_est_error2, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error3, 'b', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error4, 'r', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error5, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error6, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error7, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error8, 'g', 'LineWidth', 2.5);

% 每隔4个数据点选取一个
idx = 1:2:length(t1);

semilogy(t1(idx), q_est_2s_error(idx), 'b',  'LineWidth', 2); hold on;
semilogy(t1(idx), q_est_2s4_error(idx), 'r',  'LineWidth', 2);


semilogy(t1(idx), fun_est_error(idx), 'g', 'LineWidth', 2);
semilogy(t1(idx), ser_est_error(idx), 'm',  'LineWidth', 2);

semilogy(t1(idx), hf_est_error2(idx), 'y',  'LineWidth', 2);


xlabel('Time (s)');
ylabel('Attitude error ( ″ )');
legend('SO2+2','SO4','FI10', 'TS12','HR44');
set(legend, 'Box', 'off');  % 去掉图例边框
%title('五种姿态算法误差对比');


% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
% 主网格设置（又细又黑）
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;           % 细线宽

% 次网格设置（又细又黑，更淡一些）
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细

grid on;

% legend('二阶二子样', '二阶四子样','四子样', ...
%     '六子样','八子样','十子样','十二子样','十四子样','十六子样');


%% 保存5种算法的时间-误差数据（无冗余，列数精准）
% 第一步：确认基础数据长度（避免索引后行数不匹配）
fprintf('=== 基础数据索引确认 ===\n');
fprintf('原始t1长度：%d\n', length(t1));  % 先看t1原始行数（如T=2时通常为51）
idx = 1:2:length(t1);  % 隔2取1的索引
data_rows = length(idx);  % 索引后的数据总行数（如t1=51时，data_rows=26）
fprintf('索引后数据行数：%d\n', data_rows);  % 后续所有数据必须都是这个行数

% 第二步：提取并统一数据为【列向量】（核心！避免行数/列数混乱）
% 1. 时间数据（x轴）：按idx索引，转置为 data_rows×1 列向量
t_plot = t1(idx)';  

% 2. 5种算法误差数据（按绘图顺序，均按idx索引+转置为列向量）
so22_error = q_est_2s_error(idx)';    % 对应图例1：SO2+2
so4_error = q_est_2s4_error(idx)';     % 对应图例2：SO4
fi10_error = fun_est_error(idx)';      % 对应图例3：FI10
ts12_error = ser_est_error(idx)';      % 对应图例4：TS12
hr44_error = hf_est_error2(idx)';      % 对应图例5：HR44

% 第三步：验证所有数据行数一致（必须全等于data_rows）
fprintf('\n=== 数据行数验证（必须全为 %d） ===\n', data_rows);
fprintf('时间列行数：%d\n', size(t_plot,1));    % 应等于data_rows
fprintf('SO2+2误差行数：%d\n', size(so22_error,1));  % 应等于data_rows
fprintf('HR44误差行数：%d\n', size(hr44_error,1));  % 应等于data_rows

% 第四步：拼接数据（data_rows行 × 6列：1时间+5误差）
save_data = [t_plot, so22_error, so4_error, fi10_error, ts12_error, hr44_error];
fprintf('\n=== 最终数据结构 ===\n');
fprintf('保存矩阵：%d行 × %d列\n', size(save_data,1), size(save_data,2));  % 正确应为 data_rows×6

% 第五步：预览前3行数据（直观确认无冗余/错位）
fprintf('\n=== 前3行数据预览（每行6个值：1时间+5误差） ===\n');
disp(save_data(1:3, :));

% 第六步：精准写入Excel（避免范围溢出）
% 表头与图例完全对应，列数固定为6
headers = {'Time (s)', 'SO2+2', 'SO4', 'FI10', 'TS12', 'HR44'};
filename = 'high_2.xlsx';

% 表头仅写1行（A1:F1），数据写data_rows行（A2:F(data_rows+1)）
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1:F1');
writematrix(save_data, filename, 'Sheet', 1, 'Range', ['A2:F', num2str(data_rows+1)]);

% 结果提示
disp(['\n✅ 数据已精准保存！Excel路径：', fullfile(pwd, filename)]);
disp(['Excel结构：', num2str(data_rows), '行数据（时间点） | 6列（1时间+5算法误差）']);
disp('列对应关系：A=时间, B=SO2+2, C=SO4, D=FI10, E=TS12, F=HR44');