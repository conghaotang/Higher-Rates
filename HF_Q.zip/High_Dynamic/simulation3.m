config;

% 定义各算法的迭代次数
fun_iterations = [4, 6, 8, 10];  % Fun_iter函数的迭代次数
ser_iterations = [3, 6, 9, 12];  % Ser_exp函数的迭代次数
hf_iterations = [4, 10, 16, 22];    % Hig_Rate函数的迭代次数

% 计算总结果矩阵大小：coin值数量 × (三个算法×各自迭代次数)
total_cols = length(fun_iterations) + length(ser_iterations) + length(hf_iterations);
results = zeros(total_cols, length(t1));

% 用于存储计算时间
fun_time = zeros(1, length(fun_iterations));
ser_time = zeros(1, length(ser_iterations));
hf_time = zeros(1, length(hf_iterations));

% 定义线型样式（用于区分不同迭代次数）
line_styles = {'-', '--', '-.', ':'};

% 为每个迭代次数定义不同的标记，增强区分度
markers = {'o', 's', '^', 'd'};  % 圆形、方形、三角形、菱形


gibbs=Gibbs();
gibbs_dot = Gibbs_Dot();

omega = Omega(gibbs,gibbs_dot);

theta = Angle_Increment();

q_true = Q_true(gibbs);

%%二阶二子样算法
start_time = tic;
q_est_2s = Sec_order(theta,q_true);
end_time = toc(start_time)

%%二阶四子样
start_time = tic;
q_est_2s4 = Sec_order4(theta,q_true);
end_time = toc(start_time)


% 索引指针，用于定位当前算法结果在results中的位置
current_row = 1;

for i = 1:length(fun_iterations)
    iter = fun_iterations(i);
    % 记录开始时间
    start_time = tic;
    fun_est = Fun_iter(theta, q_true, iter);
    % 记录结束时间并计算耗时
    fun_time(i) = toc(start_time);

    fun_error = error_any(fun_est, q_true);  % 先计算完整误差序列
    % 存储误差到results矩阵（按行存储）
    results(current_row, :) = fun_error;
    
    % 移动指针到下一行
    current_row = current_row + 1;
end

% 处理Ser_exp不同迭代次数（后续可按相同逻辑添加）
for i = 1:length(ser_iterations)
    iter = ser_iterations(i);
    start_time = tic;
    ser_est = Ser_exp(theta, q_true, iter);
    ser_time(i) = toc(start_time);

    ser_error = error_any(ser_est, q_true);
    results(current_row, :) = ser_error;
    
    current_row = current_row + 1;
end

% 处理Hig_Rate不同迭代次数（后续可按相同逻辑添加）
for i = 1:length(hf_iterations)
    iter = hf_iterations(i);
    start_time = tic;
    hf_est = Hig_Rate(theta, q_true, iter);
    hf_time(i) = toc(start_time);

    hf_error = error_any(hf_est, q_true);
    results(current_row, :) = hf_error;
    current_row = current_row + 1;
end



% 创建图形
figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 11, 15]);   % Position向量：[左偏移, 下偏移, 宽度, 高度] 

algorithms = {'FI4','FI6','FI8','FI10',...
    'TS3','TS6','TS9','TS12',...
    'HR8','HR20','HR32','HR44'};

% 2. 定义采样间隔：每隔2个点取1个（索引为1,3,5...）
sample_step = 4;  % 间隔步数，可根据密集程度调整为3、4等
sample_idx = 1:sample_step:length(t1);  % 生成采样索引（1开始，步长2）

% 统一线宽设置
line_width = 1;

% 绘制Fun_iter不同迭代次数的结果（蓝色系）
color = 'b';
row_idx = 1;
for i = 1:length(fun_iterations)
    % 关键：只绘制采样后的点（t1和results都按sample_idx采样）
    semilogy(t1(sample_idx), results(row_idx, sample_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...
        'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', color, ...
        'MarkerFaceColor', [0.8 0.8 1]);
    row_idx = row_idx + 1;
    hold on;
end

% 绘制Ser_exp不同迭代次数的结果（红色系）
color = 'r';
for i = 1:length(ser_iterations)
    semilogy(t1(sample_idx), results(row_idx, sample_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...
        'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', color, ...
        'MarkerFaceColor', [1 0.8 0.8]);
    row_idx = row_idx + 1;
end

% 绘制Hig_Rate不同迭代次数的结果（绿色系）
color = 'g';
for i = 1:length(hf_iterations)
    semilogy(t1(sample_idx), results(row_idx, sample_idx), ...
        'Color', color, ...
        'Marker', markers{i}, ...
        'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, ...
        'MarkerSize', 6, ...
        'MarkerEdgeColor', color, ...
        'MarkerFaceColor', [0.8 1 0.8]);
    row_idx = row_idx + 1;
end

% 图形优化设置
xlabel('Time (s)','FontSize', 14);
ylabel('Attitude error ( ″ )','FontSize', 14);
ylim([1e-12,1])
% 缩小图例字体避免拥挤，增加图例列数减少纵向占用

%legend(algorithms, 'FontSize', 8, 'Location', 'best', 'NumColumns', 2);
% 设置图例在右边框外部
legend(algorithms, ...
    'Location', 'best', ...  % 核心：外部正上方
       'FontSize', 14, ...              % 调整字体大小
       'NumColumns', 3, ...            % 单列显示
       'Box', 'off');                  % 去掉图例边框

% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
% 主网格设置（又细又黑）
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;           % 细线宽

% 次网格设置（又细又黑，更淡一些）
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细


set(legend, 'Box', 'off');  % 去掉图例边框
grid on;
box on;
set(gca, 'FontSize', 14);

hold off;

%% 保存三大类算法的时间-误差数据（匹配采样索引）
% 1. 明确采样索引和数据结构（与绘图完全一致）
sample_step = 4;  % 与绘图中的采样步长保持一致
sample_idx = 1:sample_step:length(t1);  % 采样索引（1,5,9...）
sample_rows = length(sample_idx);  % 采样后的数据总行数（如t1=100时，约25行）

% 2. 提取采样后的时间数据（x轴），转置为列向量（sample_rows×1）
t_sample = t1(sample_idx)';  

% 3. 提取采样后的误差数据（按算法顺序，与results行对应）
% 初始化误差数据矩阵（sample_rows行 × 12列，对应12种算法）
error_sample = zeros(sample_rows, length(algorithms));

% 按行提取results中采样后的误差，转置为列向量存入error_sample
for col = 1:length(algorithms)
    % results第col行是该算法的完整误差，按sample_idx采样后转置为列向量
    error_sample(:, col) = results(col, sample_idx)';  
end

% 4. 验证数据维度（确保时间与误差行数一致）
fprintf('=== 数据维度验证 ===\n');
fprintf('采样后时间行数：%d\n', size(t_sample,1));  % 应等于sample_rows
fprintf('误差数据行数：%d\n', size(error_sample,1));  % 应等于sample_rows
fprintf('误差数据列数：%d（与算法数量一致）\n', size(error_sample,2));  % 应等于12

% 5. 拼接最终数据（时间列 + 12列误差，共sample_rows×13矩阵）
save_data = [t_sample, error_sample];

% 6. 表头设置（与图例1:1对应）
headers = [{'Time (s)'}, algorithms];  % 第一列时间，后续12列对应algorithms

% 7. 精准写入Excel（锁定范围，避免溢出）
filename = 'high_3.xlsx';
% 表头写入A1:M1（13列）
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1:M1');
% 数据写入A2:M(sample_rows+1)（sample_rows行）
writematrix(save_data, filename, 'Sheet', 1, 'Range', ['A2:M', num2str(sample_rows+1)]);

% 8. 结果验证与提示
fprintf('\n=== 数据保存结果 ===\n');
fprintf('保存矩阵：%d行 × %d列\n', size(save_data,1), size(save_data,2));  % 正确应为sample_rows×13
disp(['数据已保存到：', fullfile(pwd, filename)]);
disp('列对应关系：A=时间, B=FI4, C=FI6, ..., M=HR44（与图例完全一致）');
