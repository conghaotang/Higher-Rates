
clc;clear;
config;


gibbs=Gibbs();
gibbs_dot = Gibbs_Dot();

omega = Omega(gibbs,gibbs_dot);

theta = Angle_Increment();

q_true = Q_true(gibbs);

%%函数迭代
start_time = tic;
fun_est = Fun_iter(theta,q_true,12);
end_time = toc(start_time)

%%级数展开
start_time = tic;
ser_est = Ser_exp(theta,q_true,12);
end_time = toc(start_time)

%%高频输出
hf_est2 = Hig_Rate(theta,q_true,2);
hf_est3 = Hig_Rate(theta,q_true,3);
hf_est4 = Hig_Rate(theta,q_true,4);
hf_est5 = Hig_Rate(theta,q_true,5);
hf_est6 = Hig_Rate(theta,q_true,6);
hf_est7 = Hig_Rate(theta,q_true,7);
hf_est8 = Hig_Rate(theta,q_true,8);
hf_est9 = Hig_Rate(theta,q_true,9);

%%误差分析
%q_est_2s_error = error_any(q_est_2s,q_true);
%q_est_2s4_error = error_any(q_est_2s4,q_true);
ser_est_error = error_any(ser_est,q_true);
fun_est_error = error_any(fun_est,q_true);

hf_est_error2 = error_any(hf_est2,q_true);
hf_est_error3 = error_any(hf_est3,q_true);
hf_est_error4 = error_any(hf_est4,q_true);
hf_est_error5 = error_any(hf_est5,q_true);
hf_est_error6 = error_any(hf_est6,q_true);
hf_est_error7 = error_any(hf_est7,q_true);
hf_est_error8 = error_any(hf_est8,q_true);
hf_est_error9 = error_any(hf_est9,q_true);


figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 11, 11]);   % Position向量：[左偏移, 下偏移, 宽度, 高度] 
% semilogy(t1, q_est_2s_error, 'b', 'LineWidth', 2.5); hold on;
% semilogy(t1, q_est_2s4_error, 'r', 'LineWidth', 2.5);
% %semilogy(t1, fun_est_error, 'b', 'LineWidth', 2.5); 
% %semilogy(t1, ser_est_error, 'r', 'LineWidth', 2.5);
% 
% semilogy(t1, hf_est_error2, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error3, 'b', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error4, 'r', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error5, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error6, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error7, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error8, 'g', 'LineWidth', 2.5);

% 每隔4个数据点选取一个
idx = 1:2:length(t1);

 %semilogy(t1(idx), q_est_2s_error(idx), 'b', 'Marker', 'o', 'LineWidth', 2); hold on;
 %semilogy(t1(idx), q_est_2s4_error(idx), 'r', 'Marker', 's', 'LineWidth', 2);


semilogy(t1(idx), hf_est_error2(idx), 'g',   'LineWidth', 1.5);hold on;
semilogy(t1(idx), hf_est_error3(idx), 'c',   'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error4(idx), 'm',   'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error5(idx), 'y',   'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error6(idx), 'k',   'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error7(idx), 'b',   'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error8(idx), 'r',  'LineWidth', 1.5);
semilogy(t1(idx), hf_est_error9(idx), 'g',  'LineWidth', 1.5);

xlabel('Time (s)');
ylabel('Attitude error ( ″ )');
legend('HR4', 'HR6','HR8','HR10','HR12','HR14','HR16','HR18');
set(legend, 'Box', 'off');  % 去掉图例边框
ylim([1e-11,1e-4])
% 生成等比例递增的刻度（从1e-11到1e-4，每次乘以10）
y_ticks = [1e-11, 1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4];
yticks(y_ticks); % 必须先设置刻度位置
ytickformat('%.1e'); % 科学计数法格式（1位小数）
% （可选）自定义刻度标签格式（避免科学计数法显示不美观）

% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
% 主网格设置（又细又黑）
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;           % 细线宽

% 次网格设置（又细又黑，更淡一些）
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细

%title('五种姿态算法误差对比');
grid on;
get(gca, 'YTick') % 查看当前刻度位置
% legend('二阶二子样', '二阶四子样','四子样', ...
%     '六子样','八子样','十子样','十二子样','十四子样','十六子样');


%% 精准控制数据行数和列数，解决“第一列冗余+列数异常”
% 第一步：先明确基础数据的长度（避免后续索引错误）
% 假设你的T=2，t1=0.04:0.04:2 → 计算t1的真实长度（0.04到2共51个点：(2-0.04)/0.04 +1 = 51）
fprintf('=== 基础数据长度确认 ===\n');
fprintf('t1（原始时间）长度：%d\n', length(t1));  % 应显示51（关键！）
idx = 1:2:length(t1);  % 隔2取1，索引后长度应为26（51个点隔2取1：(51+1)/2=26）
fprintf('idx索引后数据长度：%d\n', length(idx));  % 应显示26（这是最终数据行数）

% 第二步：提取数据（强制用idx锁定行数，确保所有数据都是26行）
% 时间数据：从t1按idx提取，转置为26×1列向量（第一列，无冗余）
t_plot = t1(idx)';  
% 误差数据：从各误差变量按idx提取，转置为26×1列向量（8列，无多余）
hr4_error = hf_est_error2(idx)';  
hr6_error = hf_est_error3(idx)';  
hr8_error = hf_est_error4(idx)';  
hr10_error = hf_est_error5(idx)';  
hr12_error = hf_est_error6(idx)';  
hr14_error = hf_est_error7(idx)';  
hr16_error = hf_est_error8(idx)';  
hr18_error = hf_est_error9(idx)';  

% 第三步：验证所有数据行数一致（必须都是26行）
fprintf('\n=== 数据行数验证（必须全为26） ===\n');
fprintf('时间列行数：%d\n', size(t_plot,1));    % 26
fprintf('HR4误差列行数：%d\n', size(hr4_error,1));  % 26
fprintf('HR18误差列行数：%d\n', size(hr18_error,1));% 26

% 第四步：拼接数据（26行×9列：1列时间+8列误差，无多余列）
save_data = [t_plot, hr4_error, hr6_error, hr8_error, hr10_error, hr12_error, hr14_error, hr16_error, hr18_error];
fprintf('\n=== 最终数据结构（必须是26行×9列） ===\n');
fprintf('保存矩阵：%d行 × %d列\n', size(save_data,1), size(save_data,2));

% 第五步：预览前3行数据（确认无冗余，直观检查）
fprintf('\n=== 前3行数据预览（确保每行9个值） ===\n');
disp(save_data(1:3, :));  % 显示前3行，每行应是“1个时间+8个误差”，共9个值

% 第六步：精准写入Excel（避免范围重叠，列数严格9列）
headers = {'Time (s)', 'HR4', 'HR6', 'HR8', 'HR10', 'HR12', 'HR14', 'HR16', 'HR18'};
filename = 'high_1.xlsx';

% 表头仅写1行（A1到I1），不扩展
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1:I1');
% 数据仅写26行（A2到I27），与save_data行数完全匹配（26行）
writematrix(save_data, filename, 'Sheet', 1, 'Range', 'A2:I27');

disp('\n✅ 数据已精准保存！Excel结构：');
disp('行数：26行（26个时间点） | 列数：9列（1时间+8误差）');
disp('第一列（A列）：仅26个时间值，无冗余；列数固定9列，无多余行');