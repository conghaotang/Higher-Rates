clc;
config;
global t dt;
o=0.48*pi;
A = 3*[1, o, -o^2/2, -o^3/6,o^4/24,o^5/120,-o^6/720,-o^7/5040;
    0, o, 0, -2*o^3/3,0,-2*o^5/15,0,-4*o^7/315;
    -1,o,o^2/2,-o^3/6,-o^4/24,o^5/120,o^6/720,-o^7/5040];
omega = zeros(3, N);
omega_acc = zeros(3, N);
for i = 1:length(t)
    time_now =i*dt;
    time_vec = [1; time_now; time_now^2; time_now^3; time_now^4;time_now^5;time_now^6;time_now^7];
    gibbs1 = A(1:3, :) * time_vec;
    dtime_vec_now = [0; 1; 2*time_now; 3*time_now^2;4*time_now^3;5*time_now^4;6*time_now^5;7*time_now^6];
    gibbs_dot1 = A(1:3, :) * dtime_vec_now;
    norm_g_now = 1 + norm(gibbs1)^2;
    omega_now = (2 * (gibbs_dot1 - cross(gibbs1, gibbs_dot1))) / norm_g_now;



    time_next =i*dt+1e-10;
    time_vec_next = [1; time_next; time_next^2; time_next^3; time_next^4;time_next^5;time_next^6;time_next^7];
    gibbs2 = A(1:3, :) * time_vec_next;
    dtime_vec_next = [0; 1; 2*time_next; 3*time_next^2;4*time_next^3;5*time_next^4;6*time_next^5;7*time_next^6];
    gibbs_dot2 = A(1:3, :) * dtime_vec_next;
    norm_g_next = 1 + norm(gibbs2)^2;
    omega_next = (2 * (gibbs_dot2 - cross(gibbs2, gibbs_dot2))) / norm_g_next;


    omega(:,i)= omega_now*180/pi;
    omega_acc(:,i)= (omega_next-omega_now)*180/pi/1e-10;

end

% ---------- 第一步：创建主坐标轴（左侧Y轴：角速度） ----------
ax1 = gca;
hold on;
% 绘制角速度（实线，颜色区分轴系）
plot(t, omega(1,:), 'r-', 'LineWidth', 1.8);
plot(t, omega(2,:), 'g-', 'LineWidth', 1.8);
plot(t, omega(3,:), 'b-', 'LineWidth', 1.8);

% 设置主坐标轴样式
ax1.XLabel.String = '时间 (s)';
ax1.YLabel.String = '角速度 (°/s)';
ax1.YColor = [0,0,0];  % 左侧Y轴标签颜色（黑色）
ax1.FontSize = 11;
ax1.GridLineStyle = '--';
ax1.MinorGridLineStyle = ':';

% ---------- 第一步：数据预处理 ----------
omega = clean_data(omega);
omega_acc = clean_data(omega_acc);

% ---------- 第二步：创建主坐标轴（左侧Y轴：角速度） ----------
figure('Color','w'); % 先创建新图窗，避免坐标轴层级混乱
ax1 = gca;
hold(ax1, 'on'); % 显式指定ax1的hold on，避免上下文丢失
% 绘制角速度（实线，保存句柄）
h1 = plot(ax1, t, omega(1,:), 'r-', 'LineWidth', 1.8);
h2 = plot(ax1, t, omega(2,:), 'g-', 'LineWidth', 1.8);
h3 = plot(ax1, t, omega(3,:), 'b-', 'LineWidth', 1.8);

% 设置主坐标轴样式
ax1.XLabel.String = 'Time (s)';
ax1.YLabel.String = '\omega (deg/s)';
ax1.YLabel.Interpreter = 'tex';
ax1.YColor = [0,0,0];
ax1.FontSize = 11;
ax1.GridLineStyle = '--';
ax1.MinorGridLineStyle = ':';
ax1_ylim = get_safe_ylim(omega);
ax1.YLim = ax1_ylim;

% ---------- 第三步：创建次坐标轴（右侧Y轴：角加速度） ----------
ax2 = axes('Parent', ax1.Parent, ... % 绑定到同一图窗
           'Position', ax1.Position, ...
           'XAxisLocation', 'bottom', ...
           'YAxisLocation', 'right', ...
           'Color', 'none', ... % 透明背景，关键！
           'XLim', ax1.XLim);
hold(ax2, 'on'); % 显式指定ax2的hold on，确保曲线绘制到ax2上
% 绘制角加速度（虚线，指定绘制到ax2，核心！）
h4 = plot(ax2, t, omega_acc(1,:), 'r--', 'LineWidth', 1.5);
h5 = plot(ax2, t, omega_acc(2,:), 'g--', 'LineWidth', 1.5);
h6 = plot(ax2, t, omega_acc(3,:), 'b--', 'LineWidth', 1.5);

% 设置次坐标轴样式
ax2.XTick = []; % 隐藏X刻度，避免重复
ax2.YLabel.String = 'd\omega/dt (deg/s^2)';
ax2.YLabel.Interpreter = 'tex';
ax2.YColor = [0.5,0.5,0.5];
ax2.FontSize = 11;
ax2_ylim = get_safe_ylim(omega_acc);
ax2.YLim = ax2_ylim;

% ---------- 第四步：合并图例 + 层级调整（关键：不遮挡次坐标轴） ----------
legend_items = [h1, h2, h3, h4, h5, h6];
legend_labels = {
    '\omega_x',     
    '\omega_y',     
    '\omega_z',     
    'd\omega_x/dt', 
    'd\omega_y/dt', 
    'd\omega_z/dt'  
};
% 先创建图例，再调整层级（避免遮挡）
lgd = legend(legend_items, legend_labels, 'Location', 'best', 'Box', 'off');
lgd.FontSize = 10;
lgd.Interpreter = 'tex';

% 层级调整：仅把ax1的标签/网格置顶，不遮挡ax2的曲线
uistack(ax1.YLabel, 'top');
uistack(ax1.XLabel, 'top');
uistack(ax1.Grid, 'top');

% 联动X轴
linkaxes([ax1,ax2], 'x');

% ---------- 辅助函数 ----------
function data = clean_data(data)
    data(isnan(data)) = 0;
    data(isinf(data)) = 0;
end

function ylim = get_safe_ylim(data)
    min_val = min(min(data));
    max_val = max(max(data));
    if min_val == max_val
        if min_val == 0
            ylim = [-1, 1];
        else
            ylim = [min_val*0.9, max_val*1.1];
        end
    else
        ylim = [min_val - 0.1*abs(min_val), max_val + 0.1*abs(max_val)];
    end
end
% ===================== 4. 数据存储到Excel（7列格式） =====================
% ---------- 配置存储参数 ----------
save_filename = 'omega_acc_7cols_data.xlsx';  % Excel文件名（可自定义路径）

% ---------- 整理7列数据 ----------
% 列顺序：1.时间  2.角速度X  3.角速度Y  4.角速度Z  5.角加速度X  6.角加速度Y  7.角加速度Z
data_matrix = [
    t', ...                  % 第1列：时间 (s)
    omega(1,:)', ...         % 第2列：角速度X (°/s)
    omega(2,:)', ...         % 第3列：角速度Y (°/s)
    omega(3,:)', ...         % 第4列：角速度Z (°/s)
    omega_acc(1,:)', ...     % 第5列：角加速度X (°/s²)
    omega_acc(2,:)', ...     % 第6列：角加速度Y (°/s²)
    omega_acc(3,:)'          % 第7列：角加速度Z (°/s²)
];

% ---------- 定义7列表头 ----------
headers = {
    'Times (s)', ...
    'dx', ...
    'dy', ...
    'dz', ...
    '角加速度X (°/s²)', ...
    '角加速度Y (°/s²)', ...
    '角加速度Z (°/s²)'
};

% ---------- 写入Excel（单个Sheet，7列数据） ----------
writecell(headers, save_filename, 'Sheet', 1, 'Range', 'A1');  % 写入表头
writematrix(data_matrix, save_filename, 'Sheet', 1, 'Range', 'A2');  % 写入数据

% 提示完成
fprintf('7列数据已成功存储到Excel！\n');
fprintf('文件路径：%s\n', fullfile(pwd, save_filename));
fprintf('列格式：1.时间 | 2-4.角速度X/Y/Z | 5-7.角加速度X/Y/Z\n');