clc;
clearvars except config; config; 
close all;

% ===================== 系统级配置：确保计时精度 =====================
% 1. 固定MATLAB运算线程数（避免多核调度波动）
maxNumCompThreads(1);  
% 2. 禁用JIT加速波动（可选，极端高精度需求时用）
% feature('jit', 'off');
% 3. 核心计时参数
run_times = 1;          % 有效重复次数
warmup_times = 3;        % 预热次数（不计入统计）
fprintf('开始执行 %d 次预热 + %d 次有效运行，统计算法平均耗时...\n', warmup_times, run_times);

% ===================== 1. 算法配置（按子样数升序排列） =====================
% 基础算法迭代次数（严格按子样数升序，便于后续校验）
fun_iterations = [4, 6, 8, 10];  % 子样数升序
ser_iterations = [5, 8, 11, 14];% 子样数升序
hf_iterations = [8, 20, 32, 44];  % 子样数升序
extra_alg_names = {'二阶二子样', '二阶四子样'};  

% 合并所有算法名称（共14种，严格对应子样升序）
all_alg_names = {
    'FI4','FI6','FI8','FI10',...  % Fun_iter 子样升序
    'TS8','TS10','TS12','TS14',...% Ser_exp 子样升序
    'HR8','HR20','HR32','HR44',...% Hig_Rate 子样升序
    '二阶二子样','二阶四子样'     % 额外算法 子样升序
};
% 提前定义绘图/存储用的algorithms变量
algorithms = {'FI4','FI6','FI8','FI10','TS8','TS10','TS12','TS14','HR8','HR20','HR32','HR44'};

% ===================== 2. 初始化变量 =====================
% 高精度计时矩阵（run_times行 × 14列）
all_run_times = zeros(run_times, length(all_alg_names));
% 结果矩阵（兼容原有逻辑）
total_cols = length(fun_iterations) + length(ser_iterations) + length(hf_iterations);
results = zeros(total_cols, length(t1));

% ===================== 3. 固定参数预计算（仅算一次） =====================
gibbs = Gibbs();
gibbs_dot = Gibbs_Dot();
omega = Omega(gibbs, gibbs_dot);
theta = Angle_Increment();
q_true = Q_true(gibbs);

%% 3. 加噪（三轴独立加）
    n = size(theta, 2);
    noise = sigma_delta_theta * randn(3, n);    % 高斯白噪声
    theta = theta + noise + bias_delta_theta;


% ===================== 4. 算法预热（消除缓存/编译干扰） =====================
fprintf('正在执行 %d 次预热运行...\n', warmup_times);
for warmup_idx = 1:warmup_times
    % 预热：按顺序运行所有算法（不计入统计）
    % 额外算法
    q_est_2s = Sec_order(theta, q_true);
    q_est_2s4 = Sec_order4(theta, q_true);
    % Fun_iter
    for i = 1:length(fun_iterations)
        fun_est = Fun_iter(theta, q_true, fun_iterations(i));
    end
    % Ser_exp
    for i = 1:length(ser_iterations)
        ser_est = Ser_exp(theta, q_true, ser_iterations(i));
    end
    % Hig_Rate
    for i = 1:length(hf_iterations)
        hf_est = Hig_Rate(theta, q_true, hf_iterations(i));
    end
end
fprintf('预热完成，开始正式计时...\n');

% ===================== 5. 高精度计时循环（核心修改） =====================
for run_idx = 1:run_times
    fprintf('正在执行第 %d/%d 次有效运行...\n', run_idx, run_times);
    % 清空内存缓存
    clearvars -except config all_run_times results theta q_true gibbs gibbs_dot omega run_idx run_times warmup_times all_alg_names algorithms fun_iterations ser_iterations hf_iterations extra_alg_names;
    pause(0.1);  % 短暂暂停，稳定系统负载

    % ---------- 5.1 定义计时函数（用timeit实现高精度） ----------
    % 二阶二子样（第13列）
    f_2s = @() Sec_order(theta, q_true);
    all_run_times(run_idx, 13) = timeit(f_2s);

    % 二阶四子样（第14列）
    f_2s4 = @() Sec_order4(theta, q_true);
    all_run_times(run_idx, 14) = timeit(f_2s4);

    % ---------- 5.2 Fun_iter算法（1-4列，子样升序） ----------
    current_col = 1;
    for i = 1:length(fun_iterations)
        iter = fun_iterations(i);
        f_fun = @() Fun_iter(theta, q_true, iter);
        all_run_times(run_idx, current_col) = timeit(f_fun);

        % 仅第一次运行存储误差
        if run_idx == 1
            fun_error = error_any(Fun_iter(theta, q_true, iter), q_true);
            results(current_col, :) = fun_error;
        end
        current_col = current_col + 1;
    end

    % ---------- 5.3 Ser_exp算法（5-8列，子样升序） ----------
    for i = 1:length(ser_iterations)
        iter = ser_iterations(i);
        f_ser = @() Ser_exp(theta, q_true, iter);
        all_run_times(run_idx, current_col) = timeit(f_ser);

        if run_idx == 1
            ser_error = error_any(Ser_exp(theta, q_true, iter), q_true);
            results(current_col, :) = ser_error;
        end
        current_col = current_col + 1;
    end

    % ---------- 5.4 Hig_Rate算法（9-12列，子样升序） ----------
    for i = 1:length(hf_iterations)
        iter = hf_iterations(i);
        f_hf = @() Hig_Rate(theta, q_true, iter);
        all_run_times(run_idx, current_col) = timeit(f_hf);

        if run_idx == 1
            hf_error = error_any(Hig_Rate(theta, q_true, iter), q_true);
            results(current_col, :) = hf_error;
        end
        current_col = current_col + 1;
    end
end

% ===================== 6. 统计与异常校验 =====================
% 6.1 基础统计
avg_run_times = mean(all_run_times, 1);    % 平均耗时
std_run_times = std(all_run_times, 0, 1); % 标准差
min_run_times = min(all_run_times, [], 1);% 最小耗时
max_run_times = max(all_run_times, [], 1);% 最大耗时

% % 6.2 自动校验：高子样算法耗时是否小于低子样
% fprintf('\n=====================================\n');
% fprintf('              耗时异常校验\n');
% fprintf('=====================================\n');
% % Fun_iter校验（4→6→8→10）
% fun_avg = avg_run_times(1:4);
% for i = 2:4
%     if fun_avg(i) < fun_avg(i-1)
%         fprintf('⚠️ 异常：FI%d 耗时(%.6fs) < FI%d 耗时(%.6fs)\n', fun_iterations(i), fun_avg(i), fun_iterations(i-1), fun_avg(i-1));
%     end
% end
% % Ser_exp校验（8→10→12→14）
% ser_avg = avg_run_times(5:8);
% for i = 2:4
%     if ser_avg(i) < ser_avg(i-1)
%         fprintf('⚠️ 异常：TS%d 耗时(%.6fs) < TS%d 耗时(%.6fs)\n', ser_iterations(i), ser_avg(i), ser_iterations(i-1), ser_avg(i-1));
%     end
% end
% % Hig_Rate校验（8→20→32→44）
% hf_avg = avg_run_times(9:12);
% for i = 2:4
%     if hf_avg(i) < hf_avg(i-1)
%         fprintf('⚠️ 异常：HR%d 耗时(%.6fs) < HR%d 耗时(%.6fs)\n', hf_iterations(i), hf_avg(i), hf_iterations(i-1), hf_avg(i-1));
%     end
% end
% % 二阶算法校验
% if avg_run_times(14) < avg_run_times(13)
%     fprintf('⚠️ 异常：二阶四子样 耗时(%.6fs) < 二阶二子样 耗时(%.6fs)\n', avg_run_times(14), avg_run_times(13));
% end
% fprintf('=====================================\n');

% ===================== 7. 原有数据存储逻辑 =====================
sample_step = 4;
sample_idx = 1:sample_step:length(t1);
sample_rows = length(sample_idx);
t_sample = t1(sample_idx)';
error_sample = zeros(sample_rows, length(algorithms));

for col = 1:length(algorithms)
    error_sample(:, col) = results(col, sample_idx)';
end

save_data = [t_sample, error_sample];
headers = [{'Time (s)'}, algorithms];
filename = 'high_3_precise.xlsx';
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1:M1');
writematrix(save_data, filename, 'Sheet', 1, 'Range', ['A2:M', num2str(sample_rows+1)]);

% ===================== 8. 输出高精度耗时结果 =====================
fprintf('\n=====================================\n');
fprintf('          14种算法高精度耗时统计（%d次有效运行）\n', run_times);
fprintf('=====================================\n');
fprintf('%-10s | %-15s | %-15s | %-15s | %-15s\n', '算法名称', '平均耗时 (s)', '标准差 (s)', '最小耗时 (s)', '最大耗时 (s)');
fprintf('-------------------------------------\n');

for i = 1:length(all_alg_names)
    fprintf('%-10s | %-15.8f | %-15.8f | %-15.8f | %-15.8f\n', ...
        all_alg_names{i}, ...
        avg_run_times(i), ...
        std_run_times(i), ...
        min_run_times(i), ...
        max_run_times(i));
end
fprintf('=====================================\n');

% ===================== 9. 保存详细耗时数据到Excel =====================
% 9.1 保存每次运行的原始耗时（便于排查）
raw_time_header = [{'运行次数'}, all_alg_names];
raw_time_data = [ (1:run_times)' , all_run_times ];
writecell(raw_time_header, filename, 'Sheet', 3, 'Range', 'A1:N1');
writematrix(raw_time_data, filename, 'Sheet', 3, 'Range', 'A2:N21');

% 9.2 保存统计结果
stat_data = cell(length(all_alg_names), 4);
for i = 1:length(all_alg_names)
    stat_data{i, 1} = all_alg_names{i};
    stat_data{i, 2} = avg_run_times(i);
    stat_data{i, 3} = std_run_times(i);
    stat_data{i, 4} = (std_run_times(i)/avg_run_times(i))*100; % 变异系数(%)
end
writecell({'算法名称', '平均耗时_s', '标准差_s', '变异系数_%'}, filename, 'Sheet', 2, 'Range', 'A1:D1');
writecell(stat_data, filename, 'Sheet', 2, 'Range', 'A2:D15');

fprintf('\n✅ 高精度耗时数据已保存：\n');
fprintf('   - Sheet1：误差数据\n');
fprintf('   - Sheet2：耗时统计（平均/标准差/变异系数）\n');
fprintf('   - Sheet3：每次运行的原始耗时\n');

% 恢复系统配置
maxNumCompThreads('automatic');
% feature('jit', 'on');