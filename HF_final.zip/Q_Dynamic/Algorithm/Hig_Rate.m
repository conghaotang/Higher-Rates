function hf_est = Hig_Rate(theta,q_true,expan)
%HIG_RATE 此处显示有关此函数的摘要
%   此处显示详细说明
config;
%global  N n_coff update_interval dt

hf_est=zeros(4,(N-1)/n_coff);
Y=zeros(3,n_coff);
G=zeros(n_coff,n_coff);

k=2*expan;
start_time=0;
for  l=1:k
        t_resample_start = start_time + (l-1)*update_interval/k;
        t_resample_end = start_time + l*update_interval/k;
        for m=1:n_coff
            H(m,l) = (t_resample_end^m - t_resample_start^m);
        end
 end
for n=1:(N-1)/n_coff
    start_time=0;
    for l=1:n_coff
        t_sample_start = start_time + (l-1)*dt;
        t_sample_end = start_time + l*dt;
        for m = 1:n_coff
            G(m, l) = (t_sample_end^m - t_sample_start^m);
        end
        Y(:,l)=theta(:,n_coff*n-n_coff+l);
    end
    A=Y*pinv(G);
    theta_resample = A*H;
    result=[1;0;0;0];
    for i=2:2:k
        % 提取相邻两个子样（假设采样间隔为dt）
        theta1 = theta_resample(:,i-1);
        theta2 = theta_resample(:,i);
        % 等效旋转矢量（式13）
        g_12 = theta1 + theta2 + (2/3)*cross(theta1, theta2);
        % 转换为四元数增量（式14）
        phi12 = norm(g_12);
        e12 = g_12 / phi12;
        dq12 = [cos(phi12/2); e12*sin(phi12/2)];
        result= quatmultiply(result',dq12')';
    end
    result= result/norm(result);
    if n==1
        hf_est(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        hf_est(:,n)=quatmultiply(hf_est(:,n-1)',result')';
    end
end

