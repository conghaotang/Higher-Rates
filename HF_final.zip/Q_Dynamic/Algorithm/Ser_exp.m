function ser_est = Ser_exp(theta,q_true,expan)
%SER_EXP 此处显示有关此函数的摘要
%   此处显示详细说明
config;

angle_increment_matrix = zeros(3, n_coff);
t_coff = zeros(n_coff, n_coff);
ser_est=zeros(4,(N-1)/n_coff);
for n=1:(N-1)/n_coff
    result=[1;0;0;0];
    start_time1=0;
    for l = 1:n_coff
        t_sample_start = start_time1 + (l-1)*dt;
        t_sample_end = start_time1 + l*dt;
        for m = 1:n_coff
            coff_temp = n_coff - m + 1; % MATLAB 索引从 1 开始
            t_coff(m, l) = (t_sample_end^coff_temp - t_sample_start^coff_temp) / coff_temp;
        end
        angle_increment_matrix(:, l) = theta(:,n_coff*n-n_coff+l);
    end
    w = zeros(4, n_coff);
    t_coff_inv = pinv(t_coff);
    w(2:4, :) = 0.5 * angle_increment_matrix*t_coff_inv;
    angular_coeff=w;
    angular_coff=2*w;
    Taylor_Quaternion = {result};
    for i = 1:expan
        Q_i = Quaternion_Dot(Taylor_Quaternion, angular_coff, i);
        Taylor_Quaternion{end+1} = Q_i;
        dtq = Q_i * (update_interval^i) / Factorial(i);
        result = result + dtq;
    end
    if n==1
        ser_est(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        ser_est(:,n)=quatmultiply(ser_est(:,n-1)',result')';
    end
end
end

