function q_est_2s_sampled = Sec_order(theta,q_true)
%SEC_ORDER 二阶姿态更新算法 + 每隔2个提取q_est_2s
%   输入：
%       theta - 角增量矩阵（3×N）
%       q_true - 真实四元数（4×N）
%   输出：
%       q_est_2s_sampled - 每隔2个提取的q_est_2s（4×M）

global N1 N;
q_est_2s = zeros(4,N1);
q_est_2s(:,1) = q_true(:,1); % 初始姿态（修正原代码维度错误）

for k = 2:2:(N-1)/2
    % 提取相邻两个子样（假设采样间隔为dt）
    theta1 = theta(:,2*k-3);
    theta2 = theta(:,2*k-2);
    theta3 = theta(:,2*k-1);
    theta4 = theta(:,2*k);
    
    % 等效旋转矢量（式13）
    g_12 = theta1 + theta2 + (2/3)*cross(theta1, theta2);
    g_34 = theta3 + theta4 + (2/3)*cross(theta3, theta4);
    
    % 转换为四元数增量（式14）
    % 增加零值判断，避免除以0报错
    phi12 = norm(g_12);
    
    phi34 = norm(g_34);

    
    e12 = g_12 / phi12;
    e34 = g_34 / phi34;
    
    dq12 = [cos(phi12/2); e12*sin(phi12/2)];
    dq12 = dq12/norm(dq12);
    dq34 = [cos(phi34/2); e34*sin(phi34/2)];
    dq34 = dq34/norm(dq34);
    
    zl = quatmultiply(dq12',dq34')';
    
    % 四元数更新（式17-18）
    if k==2
        q_est_2s(:,k/2) = quatmultiply(q_true(:,1)',zl')';
    else
        q_est_2s(:,k/2) = quatmultiply(q_est_2s(:,k/2-1)',zl')';
    end
end

%核心修改：取2、4、6、8...列（从第2个开始，步长2）
q_est_2s_sampled = q_est_2s(:, 2:2:end);


end