function fun_est = Fun_iter(theta,q_true,iter)
%FUN_ITER 此处显示有关此函数的摘要
%   此处显示详细说明
config;

fun_est = zeros(4,(N-1)/n_coff);
angle_increment_matrix = zeros(3, n_coff);
t_coff = zeros(n_coff, n_coff);
% 计算时间系数矩阵
for n=1:(N-1)/n_coff
    result=[1;0;0;0];
    start_time=0;
    for l = 1:n_coff
        t_sample_start = start_time + (l-1)*dt;
        t_sample_end = start_time + l*dt;
        for m = 1:n_coff
            coff_temp = n_coff - m + 1; % MATLAB 索引从 1 开始
            t_coff(m, l) = (t_sample_end^coff_temp - t_sample_start^coff_temp) / coff_temp;
        end
        angle_increment_matrix(:, l) = theta(:,n_coff*n-n_coff+l);
    end
    w = zeros(4, n_coff);
    t_coff_inv = pinv(t_coff);
    w(2:4, :) = 0.5 * angle_increment_matrix*t_coff_inv;
    angular_coeff=w;
    % 提取角系数的行
    W0 = angular_coeff(1, :);
    WX = angular_coeff(2, :);
    WY = angular_coeff(3, :);
    WZ = angular_coeff(4, :);

    % 第一个积分项
    p = length(WX);
    t_row = zeros(1,p);
    for i = 1:4
        for j=1: p
            t_row(j) = update_interval^(p - j + 1); % 示例逻辑，需根据实际需求调整
            angular_coeff(i, j) = angular_coeff(i, j) / (p - j + 1); % 避免除以零
        end
    end
    result = result + angular_coeff * t_row';
    % 迭代部分
    U = angular_coeff;
    for i1 = 2:iter
        % 提取当前 U 的行
        U0 = U(1, :);
        U1 = U(2, :);
        U2 = U(3, :);
        U3 = U(4, :);

        % 假设 Convolve 是一个已定义的函数
        U0_new = -conv(U1, WX, 'full') - conv(U2, WY,'full') - conv(U3, WZ,'full');
        U1_new = conv(U0, WX,'full') + conv(U2, WZ,'full') - conv(U3, WY,'full');
        U2_new = conv(U0, WY,'full') + conv(U3, WX,'full') - conv(U1, WZ,'full');
        U3_new = conv(U0, WZ,'full') + conv(U1, WY,'full') - conv(U2, WX,'full');

        % 更新 U 矩阵
        new_size = length(U3_new);
        U = zeros(4, new_size); % 重新初始化
        U(1, :) = U0_new;
        U(2, :) = U1_new;
        U(3, :) = U2_new;
        U(4, :) = U3_new;
        for k = 1:4
            for j=1:new_size
                U(k, j) = U(k, j)/(i1 *p -j + 1);
            end% 避免除以零
        end

        % 更新 t_row
        t_row = zeros(1,i1*p-i1+1);
        for j = 1:length(t_row)
            t_row(j) = update_interval^(i1 * p - j + 1);
        end
        % 累加结果
        result = result + U * t_row';
    end
    if n==1
        fun_est(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        fun_est(:,n)=quatmultiply(fun_est(:,n-1)',result')';
    end
end

