function result = Anglur_Dot(n)
config;
    result=zeros(n_coff,1);
    if n>=n_coff
        result=result;
    else
        result(n_coff-n,1)= Factorial(n);
    end
end
