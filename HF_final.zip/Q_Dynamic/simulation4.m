clc;clear;
config;

gibbs=Gibbs();
gibbs_dot = Gibbs_Dot();
omega = Omega(gibbs,gibbs_dot);
theta = Angle_Increment();
q_true = Q_true(gibbs);

%% 二阶二子样算法
q_est_2s = Sec_order(theta,q_true);

%% 二阶四子样
q_est_2s4 = Sec_order4(theta,q_true);

%% 函数迭代
fun_est = Fun_iter(theta,q_true,10);

%% 级数展开
ser_est = Ser_exp(theta,q_true,14);

%% 高频输出 HR 算法（参数：1,2,4,8,16,32,64,128）
hf_est1 = Hig_Rate(theta,q_true,2);
hf_est2 = Hig_Rate(theta,q_true,4);
hf_est3 = Hig_Rate(theta,q_true,6);
hf_est4 = Hig_Rate(theta,q_true,8);
hf_est5 = Hig_Rate(theta,q_true,10);
hf_est6 = Hig_Rate(theta,q_true,12);
hf_est7 = Hig_Rate(theta,q_true,14);
hf_est8 = Hig_Rate(theta,q_true,44);

%% 误差计算（全部保留）
q_est_2s_error   = error_any(q_est_2s, q_true);
q_est_2s4_error  = error_any(q_est_2s4, q_true);
ser_est_error    = error_any(ser_est, q_true);
fun_est_error    = error_any(fun_est, q_true);

hf_est_error1 = error_any(hf_est1, q_true);
hf_est_error2 = error_any(hf_est2, q_true);
hf_est_error3 = error_any(hf_est3, q_true);
hf_est_error4 = error_any(hf_est4, q_true);
hf_est_error5 = error_any(hf_est5, q_true);
hf_est_error6 = error_any(hf_est6, q_true);
hf_est_error7 = error_any(hf_est7, q_true);
hf_est_error8 = error_any(hf_est8, q_true);

%% ===================== 绘图（颜色超级清晰）=====================
figure('Units', 'centimeters','Position', [0, 0, 14, 10]); 
idx = 1:1:length(t1);

semilogy(t1(idx), q_est_2s_error(idx),    'Color', [0.0 0.6 1], 'Marker','o','LineWidth',2); hold on;
semilogy(t1(idx), q_est_2s4_error(idx),   'Color', [1 0.2 0.2], 'Marker','s','LineWidth',2); hold on;
semilogy(t1(idx), ser_est_error(idx),     'Color', [0.2 1 0.4], 'LineWidth',1.5); hold on;
semilogy(t1(idx), fun_est_error(idx),     'Color', [1 0.6 0], 'LineWidth',1.5); hold on;

% HR 亮色 → 深色渐变
semilogy(t1(idx), hf_est_error1(idx), 'Color', [1,0.85,0], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error2(idx), 'Color', [0.8,0.6,1], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error3(idx), 'Color', [0,0.9,0.9], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error4(idx), 'Color', [0.9,0.4,0.4], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error5(idx), 'Color', [0.3,0.6,1], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error6(idx), 'Color', [0.6,0.6,0], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error7(idx), 'Color', [0.6,0,0.6], 'LineWidth',1.5); hold on;
semilogy(t1(idx), hf_est_error8(idx), 'Color', [0.2,0.2,0.2], 'LineWidth',1.5); hold on;

xlabel('Time (s)');
ylabel('Attitude error ( ″ )');
grid on;
ax = gca;
ax.YGrid = 'on'; ax.GridLineStyle = '--'; ax.GridColor = [0 0 0]; ax.GridLineWidth = 1;
ax.YMinorGrid = 'on'; ax.MinorGridColor = [0.3 0.3 0.3]; ax.MinorGridLineWidth=0.2;
ytickformat('%.1e');

% 图例自动匹配 HR 真实参数
legend('SO2+2','SO4','TS','FI',...
       'HR1','HR2','HR4','HR8','HR16','HR32','HR64','HR128','Location','best');
set(legend,'Box','off');

%% ===================== 保存所有误差到 Excel（自动命名）=====================
t_plot = t1(idx)';

% 所有误差（按图例顺序）
all_data = [
    t_plot, ...
    q_est_2s_error(idx)', ...
    q_est_2s4_error(idx)', ...
    ser_est_error(idx)', ...
    fun_est_error(idx)', ...
    hf_est_error1(idx)', ...
    hf_est_error2(idx)', ...
    hf_est_error3(idx)', ...
    hf_est_error4(idx)', ...
    hf_est_error5(idx)', ...
    hf_est_error6(idx)', ...
    hf_est_error7(idx)', ...
    hf_est_error8(idx)'
];

% 表头（与图例、曲线完全一致）
headers = {
    'Time(s)', ...
    'SO2+2','SO4','TS','FI',...
    'HR1','HR2','HR4','HR8','HR16','HR32','HR64','HR128'
};

filename = 'Algorithm_Errors_500Hz.xlsx';
writecell(headers, filename, 'Range', 'A1');
writematrix(all_data, filename, 'Range', 'A2');

fprintf('✅ 所有误差已保存到 Excel：%s\n', filename);
fprintf('✅ 图例与表头完全匹配：HR1/2/4/8/16/32/64/128\n');