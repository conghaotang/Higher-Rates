% 定义各算法的迭代次数
fun_iterations = [3, 6, 9, 12];  % Fun_iter函数的迭代次数
ser_iterations = [3, 6, 9, 12];  % Ser_exp函数的迭代次数
hf_iterations = [2, 4, 8, 16];    % Hig_Rate函数的迭代次数

% 初始化存储误差的变量
% 假设error_any返回的是向量，我们需要知道其长度才能正确初始化
% 先计算一次获取误差向量长度
gibbs = Gibbs();
gibbs_dot = Gibbs_Dot();
omega = Omega(gibbs, gibbs_dot);
theta = Angle_Increment();
q_true = Q_true(gibbs);

% 获取误差向量长度（假设所有误差向量长度相同）
temp_est = Fun_iter(theta, q_true, fun_iterations(1));
temp_error = error_any(temp_est, q_true);
error_length = length(temp_error);

% 初始化误差存储矩阵
fun_errors = zeros(error_length, length(fun_iterations));  % 行:时间步 列:迭代次数
ser_errors = zeros(error_length, length(ser_iterations));
hf_errors = zeros(error_length, length(hf_iterations));

% 用于存储计算时间
fun_time = zeros(1, length(fun_iterations));
ser_time = zeros(1, length(ser_iterations));
hf_time = zeros(1, length(hf_iterations));

% 定义线型样式和标记（用于绘图）
line_styles = {'-', '--', '-.', ':'};
markers = {'o', 's', '^', 'd'};  % 圆形、方形、三角形、菱形


% 处理Fun_iter不同迭代次数，保存误差和时间
for i = 1:length(fun_iterations)
    iter = fun_iterations(i);
    start_time = tic;
    fun_est = Fun_iter(theta, q_true, iter);
    fun_errors(:, i) = error_any(fun_est, q_true);  % 保存完整误差序列
    fun_time(i) = toc(start_time);
end

% 处理Ser_exp不同迭代次数，保存误差和时间
for i = 1:length(ser_iterations)
    iter = ser_iterations(i);
    start_time = tic;
    ser_est = Ser_exp(theta, q_true, iter);
    ser_errors(:, i) = error_any(ser_est, q_true);  % 保存完整误差序列
    ser_time(i) = toc(start_time);
end

% 处理Hig_Rate不同迭代次数，保存误差和时间
for i = 1:length(hf_iterations)
    iter = hf_iterations(i);
    start_time = tic;
    hf_est = Hig_Rate(theta, q_true, iter);
    hf_errors(:, i) = error_any(hf_est, q_true);    % 保存完整误差序列
    hf_time(i) = toc(start_time);
end

% 现在你可以使用这些误差数据进行绘图
% 示例绘图代码：
figure;
% 绘制Fun_iter的误差
for i = 1:length(fun_iterations)
    plot(fun_errors(:, i), [line_styles{i}, markers{i}], ...
         'DisplayName', ['Fun_iter (', num2str(fun_iterations(i)), ')']);
    hold on;
end
% 绘制Ser_exp的误差
for i = 1:length(ser_iterations)
    plot(ser_errors(:, i), [line_styles{i}, markers{i}], ...
         'DisplayName', ['Ser_exp (', num2str(ser_iterations(i)), ')']);
end
% 绘制Hig_Rate的误差
for i = 1:length(hf_iterations)
    plot(hf_errors(:, i), [line_styles{i}, markers{i}], ...
         'DisplayName', ['Hig_Rate (', num2str(hf_iterations(i)), ')']);
end

title('不同算法在不同迭代次数下的误差对比');
xlabel('时间步');
ylabel('误差');
legend;
grid on;
hold off;