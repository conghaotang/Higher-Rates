global T fs dt t t1 N N1 n_coff update_interval;

T = 2;
fs = 100;
dt = 1/fs;
n_coff = 8;
update_interval=n_coff*dt;
t = 0:dt:T;
t1 = n_coff*dt:n_coff*dt:T;
N = length(t);
N1 = length(t1);

ARW_deg_sqrt_h = 1e-4;      % 角度随机游走 deg/√h
bias_deg_h     = 1e-4;      % 零偏 deg/h
% 角度随机游走 → rad/√s
ARW_rad_sqrt_s = ARW_deg_sqrt_h * pi/180 / sqrt(3600);

% 角增量噪声标准差
sigma_delta_theta = ARW_rad_sqrt_s * sqrt(dt);

% 零偏 → rad/s
bias_radps = bias_deg_h * pi/180 / 3600;

% 零偏对应的角增量（每个采样周期的固定偏置）
bias_delta_theta = bias_radps * dt;


set(0, 'DefaultTextFontName', 'Times New Roman');      % 设置所有文本的默认字体
set(0, 'DefaultTextFontSize', 14);           % 设置所有文本的默认字号
set(0, 'DefaultAxesFontName', 'Times New Roman');      % 设置坐标轴的默认字体
set(0, 'DefaultAxesFontSize', 14);           % 设置坐标轴的默认字号
set(0, 'DefaultLegendFontName', 'Times New Roman');    % 设置图例的默认字体
set(0, 'DefaultLegendFontSize', 14);         % 设置图例的默认字号