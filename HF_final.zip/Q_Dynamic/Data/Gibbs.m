function gibbs = Gibbs()
%UNTITLED 此处显示有关此函数的摘要
%   此处显示详细说明
global t;
o=0.48*pi;
A = 3*[1, o, -o^2/2, -o^3/6,o^4/24,o^5/120,-o^6/720,-o^7/5040;
    0, o, 0, -2*o^3/3,0,2*o^5/15,0,-4*o^7/315;
    -1,o,o^2/2,-o^3/6,-o^4/24,o^5/120,o^6/720,-o^7/5040];
gibbs   = zeros(3, length(t));
for i = 1:length(t)
    time_vec = [1; t(i); t(i)^2; t(i)^3; t(i)^4;t(i)^5;t(i)^6;t(i)^7];
    gibbs(:, i) = A(1:3, :) * time_vec;
end
end

