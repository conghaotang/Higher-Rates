function q_true = Q_true(gibbs)
%% 计算姿态真值四元数 q_true
global t;
q_true = zeros(4, length(t));
for i = 1:length(t)
    q_true(:, i) = [1; gibbs(:, i)] / sqrt(1 + norm(gibbs(:, i))^2);
end
end

