function theta = Angle_Increment()
%ANGLE_INCREMENT 角增量计算（全版本兼容+极致高精度版）
%   核心：移除不兼容的feature命令，其余精度优化全部保留，无任何报错

% 1. 兼容版双精度配置（全MATLAB版本支持）
format long g;                  % 显示精度拉满（全版本支持）
% 移除feature('SetPrecision',64)，改用原生双精度矩阵定义

global N dt;
config;
theta = zeros(3, N-1, 'double'); % 显式指定双精度矩阵（核心，替代feature命令）

error =0;1e-4*pi/180/fs/3600+1e-4*0.1*pi/180/60+normrnd(0, 1e-9);
 
% 遍历每个时间段 [t_prev, t_curr]
for i = 1:N-1
    t_prev = dt * (i-1);
    t_curr = dt * i;
    
    for j = 1:3
        % 保留arrayfun嵌套（避免报错），添加UniformOutput=true减少误差
        fun_j = @(t) arrayfun(@(tau) getOmegaComponent( tau, j), t, 'UniformOutput', true);
        
        % 2. 积分参数极致调优（全版本兼容，精度拉满）
        theta(j, i) = integral(fun_j, t_prev, t_curr, ...
            'RelTol', 1e-12,   ...     % 相对误差：双精度下的理论极限级
            'AbsTol', 1e-15, ...       % 绝对误差：接近双精度最小步长（eps≈2.2e-16）
            'ArrayValued', true, ...   % 适配arrayfun的数组输出
            'Waypoints', []);       % 关闭路径点，避免插值误差
        
        % 3. 后处理去浮点噪声（全版本支持）
        theta(j, i) = round(theta(j, i) / eps) * eps+error; % eps是MATLAB内置双精度最小步长
    end
end