% 辅助函数：返回 omega_model(t) 的第 j 个分量
function comp = getOmegaComponent(t, j)
    w = Omega_model(t);  % omega_model 返回 3×1 列向量（标量 t 输入）
    comp = w(j);
end