function omega = Omega(gibbs,gibbs_dot)
%OMEGA 此处显示有关此函数的摘要
%   此处显示详细说明
global N t;
omega = zeros(3, N);
for i = 1:length(t)
    g_t = gibbs(:, i);
    dg_t = gibbs_dot(:, i);
    norm_g2 = 1 + norm(g_t)^2;
    omega(:, i) = (2 * (dg_t - cross(g_t, dg_t))) / norm_g2;
end
end

