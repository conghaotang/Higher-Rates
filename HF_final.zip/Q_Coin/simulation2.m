% config;
% 
% % 定义需要测试的coin值
% %coin_values = [0.01, 0.1, 1, 3, 20, 60,89];
% coin_values = [0.1, 0.3,0.9, 2.15, 8.8,28, 85];
% % 初始化存储结果的矩阵，每行对应一个coin值的结果
% results = zeros(length(coin_values), 5);  % 5种误差结果
% 
% % 循环处理每个coin值
% for idx = 1:length(coin_values)
%     coin_angle = coin_values(idx);  % 当前coin值
%     coin_anglur = 6*pi;             % 保持不变
% 
%     % 计算相关参数
%     [theta, q_true]=trj(coin_angle,coin_anglur);
% 
%     % 各种算法估计
%     q_est_2s = Sec_order(theta, q_true);
%     q_est_2s4 = Sec_order4(theta, q_true);
%     fun_est = Fun_iter(theta, q_true, 12);
%     ser_est = Ser_exp(theta, q_true, 25);
%     hf_est = Hig_Rate(theta, q_true, 80);
% 
%     % 误差分析
%     q_est_2s_error = error_any(q_est_2s, q_true);
%     q_est_2s4_error = error_any(q_est_2s4, q_true);
%     ser_est_error = error_any(ser_est, q_true);
%     fun_est_error = error_any(fun_est, q_true);
%     hf_est_error = error_any(hf_est, q_true);
% 
%     % 存储每种误差的最后一个元素
%     results(idx, 1) = q_est_2s_error(end);       % 二阶二子样最后误差
%     results(idx, 2) = q_est_2s4_error(end);      % 二阶四子样最后误差
%     results(idx, 3) = ser_est_error(end);        % 级数展开最后误差
%     results(idx, 4) = fun_est_error(end);        % 函数迭代最后误差
%     results(idx, 5) = hf_est_error(end);         % 高频输出最后误差
% end
% 
% % 显示结果
% algorithms = {'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};
% colors = {'b', 'r', 'g', 'm', 'c'};
% markers = {'o', 's', '^', 'd', '*'};
% 
% % 创建图形
% figure('Units', 'centimeters', ...  % 指定单位为厘米
%        'Position', [0, 0, 12, 12]);   % Position向量：[左偏移, 下偏移, 宽度, 高度]
% 
% % 绘制每种算法的误差曲线
% for i = 1:5
%     loglog(coin_values, results(:, i), 'Color', colors{i}, 'Marker', markers{i}, ...
%          'LineWidth', 2, 'MarkerSize', 11);
%     hold on;
% end
% 
% % 图形设置
% xlabel('conic angle','FontSize', 14);
% ylabel('Attitude erroes (″)');
% legend('SO2+2', 'SO4', 'TS12', 'FI12', 'HR32');
% set(legend, 'Box', 'off'); % 去掉图例边框
% grid on;
% 
% % 坐标轴设置 - 关键：关闭Y轴次网格
% ax = gca;
% % 主网格设置（又细又黑）
% ax.YGrid = 'on';                  % 显示Y轴主网格
% ax.GridLineStyle = '--';          % 保持虚线样式
% ax.GridColor = [0, 0, 0];         % 纯黑色
% ax.GridLineWidth = 1;           % 细线宽
% 
% % 次网格设置（又细又黑，更淡一些）
% ax.YMinorGrid = 'on';             % 显示Y轴次网格
% ax.MinorGridLineStyle = ':';      % 点线样式
% ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
% ax.MinorGridLineWidth = 0.2;      % 比主网格更细
% box on;
% 
% %% 保存圆锥角-姿态误差绘图数据到Excel
% % 1. 准备数据（确保维度匹配）
% % coin_values：1×7行向量（7个圆锥角），转置为7×1列向量
% % results：7×5矩阵（7行=7个圆锥角，5列=5种算法误差）
% % 横向拼接后得到 7×6 矩阵（第一列=圆锥角，后5列=各算法误差）
% save_data = [coin_values' , results];  % 关键：coin转置为列向量，与results横向拼接
% 
% % 验证数据维度（应显示 "数据矩阵维度：7  6"，7行6列）
% disp(['数据矩阵维度：', num2str(size(save_data))]);
% 
% % 2. 创建表头（与数据列一一对应）
% % 第一列=圆锥角（x轴标签），后5列=5种算法名称（对应legend和algorithms变量）
% headers = {'conic angle', 'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};
% 
% % 3. 保存到Excel
% % 文件名：明确标识“圆锥角-姿态误差”，避免与其他文件混淆
% filename = 'conic_simulation2.xlsx';
% 
% % 写入表头（从A1到F1，6列）
% writecell(headers, filename, 'Sheet', 1, 'Range', 'A1');
% % 写入数据（从A2到F8，7行数据，对应7个圆锥角）
% writematrix(save_data, filename, 'Sheet', 1, 'Range', 'A2');
% 
% % 提示保存路径（当前工作目录）
% disp(['绘图数据已保存到：', fullfile(pwd, filename)]);


clc;clear;
config;

% ===================== 核心修改：配置预生成数据的文件后缀 =====================
% 定义需要测试的圆锥角值（与你的.mat文件后缀对应）
coin_values = [0.1, 0.3, 0.9, 3, 8.8, 28,60, 90];
% 对应的.mat文件后缀（需与你生成的theta_xx.mat/q_true_xx.mat后缀完全一致）
% 例如：0.1对应theta_01.mat，2.15对应theta_215.mat，8.8对应theta_88.mat
file_suffixes = {'01', '03', '09', '3', '88', '28','60', '90'};

% 初始化存储结果的矩阵，每行对应一个coin值的结果
results = zeros(length(coin_values), 5);  % 5种误差结果

% ===================== 循环读取预生成数据并计算误差 =====================
for idx = 1:length(coin_values)
    % 1. 获取当前圆锥角对应的文件后缀
    suffix = file_suffixes{idx};
    fprintf('正在处理圆锥角 %.2f (文件后缀：%s)...\n', coin_values(idx), suffix);
    
    % 2. 构建.mat文件路径（默认当前文件夹，可修改为你的数据路径）
    theta_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['theta_', suffix, '.mat']);
    qtrue_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['q_true_', suffix, '.mat']);
    
    % 3. 检查文件是否存在，避免报错
    if ~exist(theta_file, 'file') || ~exist(qtrue_file, 'file')
        warning(['未找到后缀为 ', suffix, ' 的文件，跳过该圆锥角']);
        results(idx, :) = NaN;  % 标记为空值
        continue;
    end
    
    % 4. 读取预生成的theta和q_true（替代实时生成trj函数）
    load(theta_file, 'theta');   % 读取角增量theta
    load(qtrue_file, 'q_true');  % 读取姿态真值q_true
    
    % 5. 各种算法估计（与原代码完全一致）
    q_est_2s = Sec_order(theta, q_true);
    q_est_2s4 = Sec_order4(theta, q_true);
    fun_est = Fun_iter(theta, q_true, 12);
    ser_est = Ser_exp(theta, q_true, 16);
    hf_est = Hig_Rate(theta, q_true, 64);
    
    % 6. 误差分析（与原代码完全一致）
    q_est_2s_error = error_any(q_est_2s, q_true);
    q_est_2s4_error = error_any(q_est_2s4, q_true);
    ser_est_error = error_any(ser_est, q_true);
    fun_est_error = error_any(fun_est, q_true);
    hf_est_error = error_any(hf_est, q_true);
    
    % 7. 存储每种误差的最后一个元素
    results(idx, 1) = q_est_2s_error(end);       % 二阶二子样最后误差
    results(idx, 2) = q_est_2s4_error(end);      % 二阶四子样最后误差
    results(idx, 3) = ser_est_error(end);        % 级数展开最后误差
    results(idx, 4) = fun_est_error(end);        % 函数迭代最后误差
    results(idx, 5) = hf_est_error(end);         % 高频输出最后误差
end

% ===================== 绘图与数据保存（与原代码一致，仅少量优化） =====================
% 显示结果
algorithms = {'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};
colors = {'b', 'r', 'g', 'm', 'c'};
markers = {'o', 's', '^', 'd', '*'};

% 创建图形
figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 12, 12]);   % Position向量：[左偏移, 下偏移, 宽度, 高度]

% 绘制每种算法的误差曲线（跳过NaN值）
for i = 1:5
    % 过滤掉NaN值，避免绘图出错
    valid_idx = ~isnan(results(:, i));
    loglog(coin_values(valid_idx), results(valid_idx, i), 'Color', colors{i}, 'Marker', markers{i}, ...
         'LineWidth', 2, 'MarkerSize', 11);
    hold on;
end

% 图形设置
xlabel('conic angle','FontSize', 14);
ylabel('Attitude erroes (″)','FontSize', 14);
legend('SO2+2', 'SO4', 'TS12', 'FI12', 'HR32','FontSize', 12);
set(legend, 'Box', 'off'); % 去掉图例边框
grid on;

% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
ax.FontSize = 12;  % 统一坐标轴字体大小
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;             % 细线宽
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细
box on;

%% 保存圆锥角-姿态误差绘图数据到Excel
% 1. 准备数据（确保维度匹配）
save_data = [coin_values' , results];  % 关键：coin转置为列向量，与results横向拼接

% 验证数据维度
disp(['数据矩阵维度：', num2str(size(save_data))]);

% 2. 创建表头（与数据列一一对应）
headers = {'conic angle', 'SO2+2', 'SO4', 'TS12', 'FI12', 'HR'};

% 3. 保存到Excel
filename = 'conic_simulation2.xlsx';
writecell(headers, filename, 'Sheet', 1, 'Range', 'A1');
writematrix(save_data, filename, 'Sheet', 1, 'Range', 'A2');

% 提示保存路径
disp(['绘图数据已保存到：', fullfile(pwd, filename)]);