

clear;
clc;
coin_angle=90;
coin_anglur = 6*pi;

trj(coin_angle,coin_anglur);