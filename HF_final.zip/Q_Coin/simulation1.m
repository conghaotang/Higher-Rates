clc;clear;
config;
% % 只加载吉布斯相关变量
load('theta_1.mat');  % 工作区会出现 gibbs、gibbs_dot
% % 只加载角速度变量
load('q_true_1.mat'); % 工作区会出现 omega

%[theta, q_true]=trj(10,6*pi);

%%二阶二子样算法
start_time = tic;
q_est_2s = Sec_order(theta,q_true);
end_time = toc(start_time);
%%二阶四子样
start_time = tic;
q_est_2s4 = Sec_order4(theta,q_true);
end_time = toc(start_time);
% 
% 
% %%函数迭代
fun_est = Fun_iter(theta,q_true,12);
% 
% %%级数展开
ser_est = Ser_exp(theta,q_true,16);

%高频输出
hf_est2 = Hig_Rate(theta,q_true,4);
hf_est3 = Hig_Rate(theta,q_true,8);
hf_est4 = Hig_Rate(theta,q_true,16);
hf_est5 = Hig_Rate(theta,q_true,64);
hf_est6 = Hig_Rate(theta,q_true,64);
hf_est7 = Hig_Rate(theta,q_true,10);
% hf_est8 = Hig_Rate(theta,q_true,128);
% hf_est9 = Hig_Rate(theta,q_true,256);


%%龙格库塔
%hf_rk=HR_RK(theta,q_true,15);


%误差分析
% q_est_2s_error = error_any(q_est_2s,q_true);
% q_est_2s4_error = error_any(q_est_2s4,q_true);

ser_est_error = error_any(ser_est,q_true);

fun_est_error = error_any(fun_est,q_true);


hf_est_error2 = error_any(hf_est2,q_true);
hf_est_error3 = error_any(hf_est3,q_true);
hf_est_error4 = error_any(hf_est4,q_true);
hf_est_error5 = error_any(hf_est5,q_true);
hf_est_error6 = error_any(hf_est6,q_true);
hf_est_error7 = error_any(hf_est7,q_true);
% hf_est_error8 = error_any(hf_est8,q_true);
% hf_est_error9 = error_any(hf_est9,q_true);

%hf_rk_error=error_any(hf_rk,q_true);

figure('Units', 'centimeters', ...  % 指定单位为厘米
       'Position', [0, 0, 11, 11]);   % Position向量：[左偏移, 下偏移, 宽度, 高度]
%semilogy(t1, q_est_2s_error, 'b', 'LineWidth', 2.5); hold on;
%semilogy(t1, q_est_2s4_error, 'r', 'LineWidth', 2.5);
%semilogy(t1, fun_est_error, 'b', 'LineWidth', 2.5); 
%semilogy(t1, ser_est_error, 'r', 'LineWidth', 2.5);

% semilogy(t1, hf_est_error2, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error3, 'b', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error4, 'r', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error5, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error6, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error7, 'g', 'LineWidth', 2.5);
% semilogy(t1, hf_est_error8, 'g', 'LineWidth', 2.5);

% 每隔4个数据点选取一个
idx = 1:20:length(t1);

 %semilogy(t1(idx), q_est_2s_error(idx), 'b', 'Marker', 'o', 'LineWidth', 2); hold on;
 %semilogy(t1(idx), q_est_2s4_error(idx), 'r', 'Marker', 's', 'LineWidth', 2);


% 调整 MarkerSize 为 4（可根据需要减小到 3 或 2）
semilogy(t1(idx), hf_est_error2(idx), 'g', 'Marker', '^', 'LineWidth', 1, 'MarkerSize', 6); hold on;
semilogy(t1(idx), hf_est_error3(idx), 'c', 'Marker', 'd', 'LineWidth', 1, 'MarkerSize', 6);
semilogy(t1(idx), hf_est_error4(idx), 'm', 'Marker', 'p', 'LineWidth', 1, 'MarkerSize', 6);
semilogy(t1(idx), hf_est_error5(idx), 'y', 'Marker', '*', 'LineWidth', 1, 'MarkerSize', 6);
semilogy(t1(idx), fun_est_error(idx), 'k', 'Marker', 'h', 'LineWidth', 1, 'MarkerSize', 6);
semilogy(t1(idx), ser_est_error(idx), 'b', 'Marker', 'v', 'LineWidth', 1, 'MarkerSize', 6);
%semilogy(t1(idx), hf_est_error8(idx), 'r', 'Marker', '>', 'LineWidth', 1, 'MarkerSize', 6);
%semilogy(t1(idx), hf_est_error9(idx), 'g', 'Marker', '>', 'LineWidth', 1, 'MarkerSize', 6);

xlabel('Time (s)');
ylabel('Attitude error ( ″ )');
% ylim([1e-6, 1e-1]);  % 例如设置y轴从1e-3到1e2
legend('HR4', 'HR6','HR8','HR10','HR12','HR14','HR16');
set(legend, 'Box', 'off'); % 去掉图例边框
%title('五种姿态算法误差对比');
grid on;

% 坐标轴设置 - 关键：关闭Y轴次网格
ax = gca;
% 主网格设置（又细又黑）
ax.YGrid = 'on';                  % 显示Y轴主网格
ax.GridLineStyle = '--';          % 保持虚线样式
ax.GridColor = [0, 0, 0];         % 纯黑色
ax.GridLineWidth = 1;           % 细线宽

% 次网格设置（又细又黑，更淡一些）
ax.YMinorGrid = 'on';             % 显示Y轴次网格
ax.MinorGridLineStyle = ':';      % 点线样式
ax.MinorGridColor = [0.3, 0.3, 0.3]; % 深灰色（比主网格稍淡）
ax.MinorGridLineWidth = 0.2;      % 比主网格更细



% % 提取数据（均为1×17行向量）
% t_data = t1(idx);         % 时间数据
% error2 = hf_est_error2(idx);  % HR4误差
% error3 = hf_est_error3(idx);  % HR6误差
% error4 = hf_est_error4(idx);  % HR8误差
% error5 = hf_est_error5(idx);  % HR10误差
% error6 = hf_est_error6(idx);  % HR12误差
% %error7 = hf_est_error7(idx);  % HR14误差
% %error8 = hf_est_error8(idx);  % HR16误差
% %error9 = hf_est_error9(idx);  % HR18误差
% 
% % 关键修正：用空格分隔列向量，确保横向拼接为9列
% % 每个变量转置为列向量（17×1），拼接后为17×9矩阵（9列）
% save_data = [t_data'  error2'  error3'  error4'  error5'  error6'  ];
% 
% % 验证矩阵维度（应该是17行×9列）
% disp(['数据矩阵维度：', num2str(size(save_data))]);
% 
% % 表头（9列，与数据对应）
% headers = {'Time (s)', 'HR4', 'HR6', 'HR8', 'HR10', 'HR12'};

% % 保存到Excel
% filename = 'simulation.xlsx';
% writecell(headers, filename, 'Sheet', 1, 'Range', 'A1');  % 表头从A1到I1
% writematrix(save_data, filename, 'Sheet', 1, 'Range', 'A2');  % 数据从A2到I18（17行数据）
% 
% disp(['数据已按列保存到: ', fullfile(pwd, filename)]);
