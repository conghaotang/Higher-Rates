clc;clear;
config;

coin_anglur = 6*pi;

% 第一个圆锥运动：coin_angle = 1
coin_angle = 10*pi/180;
omega1 = Omega_wrong(coin_angle,coin_anglur);

omega1 =omega1*180/pi;
% 第二个圆锥运动：coin_angle = 10
coin_angle = 60*pi/180;
omega2 = Omega_wrong(coin_angle,coin_anglur);
omega2 =omega2*180/pi;
%% ===================== 绘制两个角速率对比图 =====================
figure('Position',[100,100,1000,700]);

% 子图1：omega1 (圆锥角 1°)
subplot(2,1,1);
plot(t, omega1(1,:), 'r', 'LineWidth',1.5); hold on;
plot(t, omega1(2,:), 'g', 'LineWidth',1.5); hold on;
plot(t, omega1(3,:), 'b', 'LineWidth',1.5); hold on;
grid on;
xlabel('Time (s)');
ylabel('Angular (°/s)');
title('\alpha = 10°');  % 希腊字母 α
legend('wx','wy','wz','Location','best');
ylim([-500, 500]);  % 统一幅度方便对比

% 子图2：omega2 (圆锥角 10°)
subplot(2,1,2);
plot(t, omega2(1,:), 'r', 'LineWidth',1.5); hold on;
plot(t, omega2(2,:), 'g', 'LineWidth',1.5); hold on;
plot(t, omega2(3,:), 'b', 'LineWidth',1.5); hold on;
grid on;
xlabel('Time (s)');
ylabel('Angular (°/s)');
title('\alpha = 60°');  % 希腊字母 α
legend('wx','wy','wz','Location','best');
ylim([-1000, 1000]);  % 统一幅度方便对比
