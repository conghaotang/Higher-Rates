% config;
% % 定义需要测试的coin值
% coin_values = [0.1, 0.3,0.9, 2.15, 8.8,28, 85];
% 
% % 定义各算法的迭代次数
% fun_iterations = [7, 10, 13, 16];  % Fun_iter函数的迭代次数
% ser_iterations = [13, 16, 19, 22];  % Ser_exp函数的迭代次数
% hf_iterations = [20, 40, 60, 80];    % Hig_Rate函数的迭代次数
% 
% % ========== 新增：稳定计时配置 ==========
% repeat_times = 10;  % 重复运行次数（建议10-50次，可根据需求调整）
% maxNumCompThreads(1); % 固定单线程运行，减少线程调度干扰
% 
% % 计算总结果矩阵大小：coin值数量 × (三个算法×各自迭代次数)
% total_cols = length(fun_iterations) + length(ser_iterations) + length(hf_iterations);
% results = zeros(length(coin_values), total_cols);
% 
% % 用于存储计算时间（改为存储每次重复的时间，后续取平均）
% fun_time_raw = zeros(length(coin_values), length(fun_iterations), repeat_times);
% ser_time_raw = zeros(length(coin_values), length(ser_iterations), repeat_times);
% hf_time_raw = zeros(length(coin_values), length(hf_iterations), repeat_times);
% 
% % 定义线型样式（用于区分不同迭代次数）
% line_styles = {'-', '--', '-.', ':'};
% 
% % 为每个迭代次数定义不同的标记，增强区分度
% markers = {'o', 's', '^', 'd'};  % 圆形、方形、三角形、菱形
% 
% 
% fprintf('预热完成，开始正式计算...\n');
% 
% % 循环处理每个coin值
% for idx = 1:length(coin_values)
%     coin_angle = coin_values(idx);  % 当前coin值
%     coin_anglur = 6*pi;             % 保持不变
% 
%     % 计算相关参数
%     [theta, q_true]=trj(coin_angle,coin_anglur);
% 
%     % 处理Fun_iter不同迭代次数，统计时间（多次重复）
%     col_idx = 1;
%     for i = 1:length(fun_iterations)
%         iter = fun_iterations(i);
%         % 重复运行repeat_times次，记录每次耗时
%         for r = 1:repeat_times
%             start_time = tic;
%             fun_est = Fun_iter(theta, q_true, iter);
%             fun_error = error_any(fun_est, q_true);  % 先计算完整误差序列
%             fun_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
%         end
%         % 误差只取最后一次运行的结果（或可改为mean，根据需求）
%         results(idx, col_idx) = fun_error(end);  
%         col_idx = col_idx + 1;
%     end
% 
%     % 处理Ser_exp不同迭代次数，统计时间（多次重复）
%     for i = 1:length(ser_iterations)
%         iter = ser_iterations(i);
%         for r = 1:repeat_times
%             start_time = tic;
%             ser_est = Ser_exp(theta, q_true, iter);
%             ser_error = error_any(ser_est, q_true);  % 先计算完整误差序列
%             ser_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
%         end
%         results(idx, col_idx) = ser_error(end);  % 再取最后一个元素
%         col_idx = col_idx + 1;
%     end
% 
%     % 处理Hig_Rate不同迭代次数，统计时间（多次重复）
%     for i = 1:length(hf_iterations)
%         iter = hf_iterations(i);
%         for r = 1:repeat_times
%             start_time = tic;
%             hf_est = Hig_Rate(theta, q_true, iter);
%             hf_error = error_any(hf_est, q_true);    % 先计算完整误差序列
%             hf_time_raw(idx, i, r) = toc(start_time); % 存储单次耗时
%         end
%         results(idx, col_idx) = hf_error(end);   % 再取最后一个元素
%         col_idx = col_idx + 1;
%     end
% 
%     % 进度提示
%     fprintf('已完成 %d/%d 个coin值的计算\n', idx, length(coin_values));
% end
% 
% % ========== 新增：计算平均时间（消除偶然误差） ==========
% % 对重复运行的时间取平均，得到稳定的计时结果
% fun_time = mean(fun_time_raw, 3);  % 沿第3维（重复次数）取平均
% ser_time = mean(ser_time_raw, 3);
% hf_time = mean(hf_time_raw, 3);
% 
% % 计算每种迭代次数下的平均计算时间
% fun_avg_time = mean(fun_time, 1);
% ser_avg_time = mean(ser_time, 1);
% hf_avg_time = mean(hf_time, 1);
% 
% % 打印统计结果
% fprintf('Fun_iter 平均计算时间 (秒)：\n');
% for i = 1:length(fun_iterations)
%     fprintf('迭代次数 %d: %.6f\n', fun_iterations(i), fun_avg_time(i));
% end
% 
% fprintf('\nSer_exp 平均计算时间 (秒)：\n');
% for i = 1:length(ser_iterations)
%     fprintf('迭代次数 %d: %.6f\n', ser_iterations(i), ser_avg_time(i));
% end
% 
% fprintf('\nHig_Rate 平均计算时间 (秒)：\n');
% for i = 1:length(hf_iterations)
%     fprintf('迭代次数 %d: %.6f\n', hf_iterations(i), hf_avg_time(i));
% end
% 
% % 创建图形（保留原尺寸）
% figure('Units', 'centimeters', 'Position', [0, 0, 11, 15]);  
% set(gca, 'FontSize', 14);
% hold on;
% 
% algorithms = {'FI3','FI6','FI9','FI12',...
%               'TS3','TS6','TS9','TS12',...
%               'HR4','HR8','HR16','HR32'};
% 
% line_width = 1;
% 
% % ========== 关键修正1：先显式设置X/Y轴为对数坐标 ==========
% ax = gca;
% ax.XScale = 'log';   % 强制X轴为对数坐标
% ax.YScale = 'log';   % 强制Y轴为对数坐标
% 
% % 绘制Fun_iter（蓝色系，保留原样式）
% color = 'b';
% col_idx = 1;
% for i = 1:length(fun_iterations)
%     plot(coin_values, results(:, col_idx), ...  % 改用plot，因为已显式设对数坐标
%         'Color', color, ...
%         'Marker', markers{i}, ...
%         'LineStyle', line_styles{i}, ...
%         'LineWidth', line_width, ...
%         'MarkerSize', 6, ...
%         'MarkerEdgeColor', color, ...
%         'MarkerFaceColor', [0.8 0.8 1]);
%     col_idx = col_idx + 1;
% end
% 
% % 绘制Ser_exp（红色系，保留原样式）
% color = 'r';
% for i = 1:length(ser_iterations)
%     plot(coin_values, results(:, col_idx), ...
%         'Color', color, ...
%         'Marker', markers{i}, ...
%         'LineStyle', line_styles{i}, ...
%         'LineWidth', line_width, ...
%         'MarkerSize', 6, ...
%         'MarkerEdgeColor', color, ...
%         'MarkerFaceColor', [1 0.8 0.8]);
%     col_idx = col_idx + 1;
% end
% 
% % 绘制Hig_Rate（绿色系，保留原样式）
% color = 'g';
% for i = 1:length(hf_iterations)
%     plot(coin_values, results(:, col_idx), ...
%         'Color', color, ...
%         'Marker', markers{i}, ...
%         'LineStyle', line_styles{i}, ...
%         'LineWidth', line_width, ...
%         'MarkerSize', 6, ...
%         'MarkerEdgeColor', color, ...
%         'MarkerFaceColor', [0.8 1 0.8]);
%     col_idx = col_idx + 1;
% end
% 
% % ========== 关键修正2：手动设置X轴对数刻度（可选，增强显示） ==========
% % 自定义X轴刻度，匹配coin_values的范围（0.1~100）
% xticks([0.1, 1, 10, 100]);  % 手动指定对数刻度点
% xticklabels({'0.1', '1', '10', '100'});  % 显示清晰的刻度标签
% 
% % 图形基础设置（保留原逻辑）
% xlabel('conic angle', 'FontSize', 14);
% ylabel('Attitude errors (″)', 'FontSize', 14);
% grid on;
% box on;
% drawnow;
% 
% % 图例设置（保留原逻辑）
% legend_obj = legend(algorithms, 'Location', 'best');
% set(legend_obj, 'Box', 'off', 'FontSize', 14, 'Interpreter', 'none');
% 
% % 坐标轴网格设置（保留原逻辑）
% ax.YGrid = 'on';                  
% ax.GridLineStyle = '--';          
% ax.GridColor = [0, 0, 0];         
% ax.GridLineWidth = 1;           
% ax.YMinorGrid = 'on';             
% ax.MinorGridLineStyle = ':';      
% ax.MinorGridColor = [0.3, 0.3, 0.3]; 
% ax.MinorGridLineWidth = 0.2;      
% 
% % ========== 补充：验证坐标类型 ==========
% fprintf('X轴坐标类型：%s\n', ax.XScale);  % 应输出 'log'
% fprintf('Y轴坐标类型：%s\n', ax.YScale);  % 应输出 'log'
% 
% hold off;
% 
% %% 修正表头维度不匹配问题
% % 1. 准备误差数据（保持不变）
% error_data = [coin_values'  results];  % 7行×13列（1列圆锥角+12列误差）
% 
% % 2. 修正表头：保持algorithms为行向量，与{'conic angle'}横向拼接
% error_headers = [{'conic angle'}, algorithms];  % 关键：去掉algorithms后的单引号'
% 
% % 验证表头维度（应显示 1×13，1行13列）
% disp(['表头维度：', num2str(size(error_headers))]);
% 
% % 3. 时间统计数据处理（保持不变）
% fun_time_data = table( ...
%     repmat({'Fun_iter'}, length(fun_iterations), 1), ...
%     fun_iterations', ...
%     fun_avg_time', ...
%     'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});
% 
% ser_time_data = table( ...
%     repmat({'Ser_exp'}, length(ser_iterations), 1), ...
%     ser_iterations', ...
%     ser_avg_time', ...
%     'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});
% 
% hf_time_data = table( ...
%     repmat({'Hig_Rate'}, length(hf_iterations), 1), ...
%     hf_iterations', ...
%     hf_avg_time', ...
%     'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});
% 
% time_stats = [fun_time_data; ser_time_data; hf_time_data];
% 
% % 4. 保存到Excel
% filename = 'conic_simulation3.xlsx';
% writecell(error_headers, filename, 'Sheet', 1, 'Range', 'A1');
% writematrix(error_data, filename, 'Sheet', 1, 'Range', 'A2');
% writetable(time_stats, filename, 'Sheet', 2, 'Range', 'A1', 'WriteVariableNames', true);
% 
% disp(['数据已保存到：', fullfile(pwd, filename)]);

clc;clear;
config;

% ===================== 1. 核心配置 =====================
coin_values = [0.1, 0.3, 0.9, 2.15, 8.8, 28,60, 85];
file_suffixes = {'01', '03', '09', '215', '88', '28','60', '85'};

% 定义各算法的迭代次数
fun_iterations = [3, 6, 9, 12];  
ser_iterations = [4, 8, 12, 16];  
hf_iterations = [8, 16, 32, 64];    

% ========== 计时配置 ==========
repeat_times = 1;  
pause(1); 

% 预热CPU
fprintf('正在预热CPU...\n');
warmup_suffix = file_suffixes{1};
warmup_theta_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['theta_', warmup_suffix, '.mat']);
warmup_qtrue_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['q_true_', warmup_suffix, '.mat']);
load(warmup_theta_file, 'theta');
load(warmup_qtrue_file, 'q_true');
dummy = Fun_iter(theta, q_true, fun_iterations(1));
dummy = Ser_exp(theta, q_true, ser_iterations(1));
dummy = Hig_Rate(theta, q_true, hf_iterations(1));
clear dummy;
fprintf('预热完成，开始正式计算...\n');

% 初始化结果矩阵
total_cols = length(fun_iterations) + length(ser_iterations) + length(hf_iterations);
results = zeros(length(coin_values), total_cols);

% 计时数组
fun_time_raw = zeros(length(coin_values), length(fun_iterations), repeat_times);
ser_time_raw = zeros(length(coin_values), length(ser_iterations), repeat_times);
hf_time_raw = zeros(length(coin_values), length(hf_iterations), repeat_times);

% 样式定义
line_styles = {'-', '--', '-.', ':'};
markers = {'o', 's', '^', 'd'};

% ===================== 2. 循环处理每个coin值 =====================
for idx = 1:length(coin_values)
    suffix = file_suffixes{idx};
    fprintf('正在处理圆锥角 %.2f (文件后缀：%s)...\n', coin_values(idx), suffix);

    % 构建文件路径
    theta_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['theta_', suffix, '.mat']);
    qtrue_file = fullfile('D:\GInav\HF\Q_Coin\coin_data', ['q_true_', suffix, '.mat']);

    % 检查文件
    if ~exist(theta_file, 'file') || ~exist(qtrue_file, 'file')
        warning(['未找到后缀为 ', suffix, ' 的文件，跳过该圆锥角']);
        results(idx, :) = NaN;  
        fun_time_raw(idx, :, :) = NaN;
        ser_time_raw(idx, :, :) = NaN;
        hf_time_raw(idx, :, :) = NaN;
        continue;
    end

    % 读取数据
    load(theta_file, 'theta');
    load(qtrue_file, 'q_true');
    %% 3. 加噪（三轴独立加）
    n = size(theta, 2);
    noise = sigma_delta_theta * randn(3, n);    % 高斯白噪声
    theta = theta + noise + bias_delta_theta;

    start_time = tic;
    q_est_2s = Sec_order(theta, q_true);
    end_time=toc(start_time)
    start_time = tic;
    q_est_2s4 = Sec_order4(theta, q_true);
    end_time=toc(start_time)

    % ========== Fun_iter（修正计时逻辑：error_any只算1次） ==========
   col_idx = 1;
    for i = 1:length(fun_iterations)
        iter = fun_iterations(i);
        % 第一步：重复运行算法，仅计时算法本身（不含error_any）
        for r = 1:repeat_times
            start_time = tic;
            fun_est = Fun_iter(theta, q_true, iter);  % 只计时算法核心
            fun_time_raw(idx, i, r) = toc(start_time);
        end
        % 第二步：仅计算1次误差（避免重复耗时）
        fun_error = error_any(fun_est, q_true);
        results(idx, col_idx) = fun_error(end);  
        col_idx = col_idx + 1;
    end

    % ========== Ser_exp（同样修正） ==========
    for i = 1:length(ser_iterations)
        iter = ser_iterations(i);
        % 重复计时算法核心
        for r = 1:repeat_times
            start_time = tic;
            ser_est = Ser_exp(theta, q_true, iter);
            ser_time_raw(idx, i, r) = toc(start_time);
        end
        % 仅算1次误差
        ser_error = error_any(ser_est, q_true);
        results(idx, col_idx) = ser_error(end);
        col_idx = col_idx + 1;
    end

    % ========== Hig_Rate（同样修正） ==========
    for i = 1:length(hf_iterations)
        iter = hf_iterations(i);
        % 重复计时算法核心
        for r = 1:repeat_times
            start_time = tic;
            hf_est = Hig_Rate(theta, q_true, iter);
            hf_time_raw(idx, i, r) = toc(start_time);
        end
        % 仅算1次误差
        hf_error = error_any(hf_est, q_true);
        results(idx, col_idx) = hf_error(end);
        col_idx = col_idx + 1;
    end

    fprintf('已完成 %d/%d 个coin值的计算\n', idx, length(coin_values));
end

% ===================== 3. 计时结果处理 =====================
fun_time = nanmean(fun_time_raw, 3);  
ser_time = nanmean(ser_time_raw, 3);
hf_time = nanmean(hf_time_raw, 3);

fun_avg_time = nanmean(fun_time, 1);
ser_avg_time = nanmean(ser_time, 1);
hf_avg_time = nanmean(hf_time, 1);

% 打印结果
fprintf('\n===================== Fun_iter 计时结果 =====================\n');
for i = 1:length(fun_iterations)
    fprintf('迭代次数 %d: 平均 %.6f 秒\n', fun_iterations(i), fun_avg_time(i));
end

fprintf('\n===================== Ser_exp 计时结果 =====================\n');
for i = 1:length(ser_iterations)
    fprintf('迭代次数 %d: 平均 %.6f 秒\n', ser_iterations(i), ser_avg_time(i));
end

fprintf('\n===================== Hig_Rate 计时结果 =====================\n');
for i = 1:length(hf_iterations)
    fprintf('迭代次数 %d: 平均 %.6f 秒\n', hf_iterations(i), hf_avg_time(i));
end

% ===================== 4. 绘图 =====================
figure('Units', 'centimeters', 'Position', [0, 0, 11, 15]);  
ax = gca;
ax.FontSize = 14;
ax.XScale = 'log';   
ax.YScale = 'log';   
hold on;

% 修正图例：匹配实际迭代次数（你的原图例和迭代次数不对应）
algorithms = {
    ['FI',num2str(fun_iterations(1))], ['FI',num2str(fun_iterations(2))], ['FI',num2str(fun_iterations(3))], ['FI',num2str(fun_iterations(4))],...
    ['TS',num2str(ser_iterations(1))], ['TS',num2str(ser_iterations(2))], ['TS',num2str(ser_iterations(3))], ['TS',num2str(ser_iterations(4))],...
    ['HR',num2str(hf_iterations(1))], ['HR',num2str(hf_iterations(2))], ['HR',num2str(hf_iterations(3))], ['HR',num2str(hf_iterations(4))]
};

line_width = 1;

% 绘制Fun_iter
color = 'b';
col_idx = 1;
for i = 1:length(fun_iterations)
    valid_idx = ~isnan(results(:, col_idx));
    plot(coin_values(valid_idx), results(valid_idx, col_idx), ...
        'Color', color, 'Marker', markers{i}, 'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, 'MarkerSize', 6, ...
        'MarkerEdgeColor', color, 'MarkerFaceColor', [0.8 0.8 1]);
    col_idx = col_idx + 1;
end

% 绘制Ser_exp
color = 'r';
for i = 1:length(ser_iterations)
    valid_idx = ~isnan(results(:, col_idx));
    plot(coin_values(valid_idx), results(valid_idx, col_idx), ...
        'Color', color, 'Marker', markers{i}, 'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, 'MarkerSize', 6, ...
        'MarkerEdgeColor', color, 'MarkerFaceColor', [1 0.8 0.8]);
    col_idx = col_idx + 1;
end

% 绘制Hig_Rate
color = 'g';
for i = 1:length(hf_iterations)
    valid_idx = ~isnan(results(:, col_idx));
    col_idx = col_idx + 1;
    plot(coin_values(valid_idx), results(valid_idx, col_idx), ...
        'Color', color, 'Marker', markers{i}, 'LineStyle', line_styles{i}, ...
        'LineWidth', line_width, 'MarkerSize', 6, ...
        'MarkerEdgeColor', color, 'MarkerFaceColor', [0.8 1 0.8]);
end

% 图形设置
xticks([0.1, 1, 10, 100]);
xticklabels({'0.1', '1', '10', '100'});
xlabel('conic angle', 'FontSize', 14);
ylabel('Attitude errors (″)', 'FontSize', 14);
grid on;
box on;

% 图例
legend_obj = legend(algorithms, 'Location', 'best');
set(legend_obj, 'Box', 'off', 'FontSize', 12, 'Interpreter', 'none');

% 网格
ax.YGrid = 'on';                  
ax.GridLineStyle = '--';          
ax.GridColor = [0, 0, 0];         
ax.GridLineWidth = 1;           
ax.YMinorGrid = 'on';             
ax.MinorGridLineStyle = ':';      
ax.MinorGridColor = [0.3, 0.3, 0.3]; 
ax.MinorGridLineWidth = 0.2;      

hold off;

% ===================== 5. 保存数据 =====================
error_data = [coin_values'  results];
error_headers = [{'conic angle'}, algorithms];

fun_time_data = table( ...
    repmat({'Fun_iter'}, length(fun_iterations), 1), ...
    fun_iterations', ...
    fun_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

ser_time_data = table( ...
    repmat({'Ser_exp'}, length(ser_iterations), 1), ...
    ser_iterations', ...
    ser_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

hf_time_data = table( ...
    repmat({'Hig_Rate'}, length(hf_iterations), 1), ...
    hf_iterations', ...
    hf_avg_time', ...
    'VariableNames', {'Algorithm', 'Iterations', 'Avg_Time(s)'});

time_stats = [fun_time_data; ser_time_data; hf_time_data];

filename = 'conic_simulation3.xlsx';
writecell(error_headers, filename, 'Sheet', 1, 'Range', 'A1');
writematrix(error_data, filename, 'Sheet', 1, 'Range', 'A2');
writetable(time_stats, filename, 'Sheet', 2, 'Range', 'A1', 'WriteVariableNames', true);

disp(['\n数据已保存到：', fullfile(pwd, filename)]);