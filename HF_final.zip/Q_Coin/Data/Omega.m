function omega = Omega(coin_angle,coin_anglur)
%OMEGA 此处显示有关此函数的摘要
%   此处显示详细说明
global N t;
omega = zeros(3, N);
for i = 1:length(t)
    omega(:, i) = Omega_model(coin_angle,coin_anglur,t(i));
end
end

