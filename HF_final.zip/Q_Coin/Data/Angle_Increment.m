% function theta = Angle_Increment(coin_angle,coin_anglur)
% %ANGLE_INCREMENT 计算角增量（分时间段直接积分，无需后续减法）
% %   输入：
% %       coin_angle: 角度相关参数
% %       coin_anglur: 角速度相关参数
% %   输出：
% %       theta: 3×(N-1)的角增量矩阵（直接为各时间段积分结果）
% %   全局变量：N(总步数), dt(时间步长)
% 
% global N dt;
% theta = zeros(3, N-1); % 直接初始化theta，无需先算alpha
% 
% % 遍历每个时间段 [t_prev, t_curr] = [(i-1)*dt, i*dt]
% for i = 1:N-1
%     t_prev = dt * (i-1); % 上一时刻（区间起点）
%     t_curr = dt * i;     % 当前时刻（区间终点）
% 
%     for j = 1:3
%         % 保留你原始的匿名函数定义
%         fun_j = @(t) arrayfun(@(tau)getOmegaComponent(coin_angle,coin_anglur,tau, j),t);
%         % 直接积分当前时间段 [t_prev, t_curr]，结果直接赋值给theta
%         theta(j, i) = integral(fun_j, t_prev, t_curr);
%     end
% end
% 
% end

% function theta = Angle_Increment(coin_angle,coin_anglur)
% %ANGLE_INCREMENT 角增量计算（全版本兼容+极致高精度版）
% %   核心：移除不兼容的feature命令，其余精度优化全部保留，无任何报错
% 
% % 双精度配置（保留，保证显示/计算精度）
% format long g;
% 
% global N dt;
% theta = zeros(3, N-1, 'double'); % 初始化角增量矩阵
% 
% % 预计算常数（减少重复计算）
% sin_theta = sin(coin_angle);          % sin(圆锥半顶角)
% sin_half_theta_sq = sin(coin_angle/2)^2; % sin(半顶角/2)²
% omega0 = coin_anglur;                % 角频率
% 
% % 遍历每个时间步，直接计算解析积分
% for i = 1:N-1
%     t_prev = dt * (i-1);  % 时间段起点
%     t_curr = dt * i;      % 时间段终点
% 
%     % 直接计算各分量解析积分（核心逻辑，一步到位）
%     theta(1, i) = sin_theta * (cos(omega0*t_curr) - cos(omega0*t_prev));  % 第1分量
%     theta(2, i) = sin_theta * (sin(omega0*t_curr) - sin(omega0*t_prev));  % 第2分量
%     theta(3, i) = -2 * omega0 * sin_half_theta_sq * (t_curr - t_prev);    % 第3分量
% 
%     % 浮点噪声后处理（可选保留，进一步消除双精度微小误差）
%     %theta(:, i) = round(theta(:, i) / eps) * eps;
% end
% end

function theta = Angle_Increment(coin_angle,coin_anglur)
%ANGLE_INCREMENT 角增量计算（全版本兼容+极致高精度版）
%   核心：移除不兼容的feature命令，其余精度优化全部保留，无任何报错

% 1. 兼容版双精度配置（全MATLAB版本支持）
format long g;                  % 显示精度拉满（全版本支持）
% 移除feature('SetPrecision',64)，改用原生双精度矩阵定义

global N dt;
theta = zeros(3, N-1, 'double'); % 显式指定双精度矩阵（核心，替代feature命令）

% 遍历每个时间段 [t_prev, t_curr]
for i = 1:N-1
    t_prev = dt * (i-1);
    t_curr = dt * i;

    for j = 1:3
        % 保留arrayfun嵌套（避免报错），添加UniformOutput=true减少误差
        fun_j = @(t) arrayfun(@(tau) getOmegaComponent(coin_angle, coin_anglur, tau, j), t, 'UniformOutput', true);

        % 2. 积分参数极致调优（全版本兼容，精度拉满）
        theta(j, i) = integral(fun_j, t_prev, t_curr);       % 关闭路径点，避免插值误差

        % 3. 后处理去浮点噪声（全版本支持）
        theta(j, i) = round(theta(j, i) / eps) * eps; % eps是MATLAB内置双精度最小步长
    end
end