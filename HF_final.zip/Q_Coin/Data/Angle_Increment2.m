function theta = Angle_Increment2(coin_angle, coin_angular)
%ANGLE_INCREMENT_ANALYTICAL 圆锥运动角增量解析计算（无积分、无arrayfun、极致高效高精度）
% 输入:
%   coin_angle  : 圆锥半顶角 α (单位: 度，内部自动转弧度)
%   coin_angular: 圆锥运动频率 f (单位: Hz，对应角频率 Ω = 2πf)
%   N           : 总采样点数 (角增量长度为 N-1)
%   dt          : 采样周期 (单位: s，dt = 1/fs，fs为采样频率)
% 输出:
%   theta       : 3×(N-1) 双精度角增量矩阵 (单位: rad)
% 核心特性:
%   1. 纯解析闭式解，无数值积分，无循环嵌套，计算效率拉满
%   2. 严格双精度，符合你要求的 round(val/eps)*eps 去噪
%   3. 无arrayfun、无feature命令，全MATLAB版本兼容
%   4. 完全匹配你论文公式(13)(14)的圆锥运动模型
config;
% 单位转换：角度 → 弧度
alpha = deg2rad(coin_angle);
%% 2. 生成时间序列 (双精度)
t_prev = dt * (0 : N-2);           % 每个区间的起始时间: t_0, t_1, ..., t_{N-2}
t_curr = dt * (1 : N-1);           % 每个区间的结束时间: t_1, t_2, ..., t_{N-1}

%% 3. 解析计算3个分量的角增量 (完全向量化，无循环)
% 分量1: ∫ -Ω sinα sin(Ωt) dt = sinα [cos(Ωt_k) - cos(Ωt_{k-1})]
theta(1, :) = sin(alpha) * (cos(coin_angular * t_curr) - cos(coin_angular * t_prev));

% 分量2: ∫ Ω sinα cos(Ωt) dt = sinα [sin(Ωt_k) - sin(Ωt_{k-1})]
theta(2, :) = sin(alpha) * (sin(coin_angular * t_curr) - sin(coin_angular * t_prev));

% 分量3: ∫ -Ω sinα tan(α/2) dt = -Ω sinα tan(α/2) * dt = -2Ω sin²(α/2) * dt
theta(3, :) = -2 * coin_angular * sin(alpha/2)^2 * dt * ones(1, N-1);

%% 4. 严格双精度去噪 (完全符合你要求的 round(val/eps)*eps)
theta = round(theta / eps) * eps;

%% 5. 强制3列格式 (你要求的最终数据维度)
theta = double(theta); % 确保双精度
end