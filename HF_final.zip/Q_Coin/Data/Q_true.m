function q_true = Q_true(coin_angle,coin_anglur)
%% 计算姿态真值四元数 q_true
global t;
q_true = zeros(4, length(t));
coin_angle = deg2rad(coin_angle);
for i = 1:length(t)
    q_true(:, i) = [cos(coin_angle/2);
        sin(coin_angle/2)*cos(coin_anglur*t(i));
        sin(coin_angle/2)*sin(coin_anglur*t(i))
        0] ;
end
end

