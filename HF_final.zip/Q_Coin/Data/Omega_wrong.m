function omega = Omega_wrong(coin_angle,coin_anglur)
%OMEGA 此处显示有关此函数的摘要
%   此处显示详细说明
global N t;
omega = zeros(3, N);
for i = 1:length(t)
    omega(:, i) = coin_anglur*[-sin(coin_angle)*sin(coin_anglur*t(i));
    sin(coin_angle)*cos(coin_anglur*t(i));
    -2*sin(coin_angle/2)^2];
end

