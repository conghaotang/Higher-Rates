function q_est_2s4_sampled = Sec_order4(theta,q_true)
%SEC_ORDER4 四阶姿态更新算法 + 每隔2个提取q_est_2s4
%   输入：
%       theta - 角增量矩阵（3×N）
%       q_true - 真实四元数（4×N）
%   输出：
%       q_est_2s4_sampled - 每隔2个提取的q_est_2s4（4×M）

global N1 N;
q_est_2s4 = zeros(4, N1);  % 初始化四元数矩阵

for k = 4:4:N-1
    % 计算当前索引m
    m = k/4;
    
    % 提取四个子样θ1-θ4（对应k-3到k列）
    theta1 = theta(:,k-3);
    theta2 = theta(:,k-2);
    theta3 = theta(:,k-1);
    theta4 = theta(:,k);

    % 等效旋转矢量（式19）
    cross_terms = cross((18/35)*theta1 + (92/105)*theta2 + (214/105)*theta3, theta4);
    g_4 = theta1 + theta2 + theta3 + theta4 + cross_terms;

    % 转换为四元数增量（增加除零保护，避免norm(g_4)=0时报错）
    phi = norm(g_4);
    e = g_4 / phi;
    dq = [cos(phi/2); e*sin(phi/2)];
    dq = dq / norm(dq);  % 归一化，保证四元数单位模

    % 四元数更新
    if k == 4
        q_est_2s4(:,m) = quatmultiply(q_true(:,1)', dq')';
    else
        q_est_2s4(:,m) = quatmultiply(q_est_2s4(:,m-1)', dq')';
    end
end

% 核心操作：每隔2个提取一个q_est_2s4（从第1列开始，步长2）
% 若需从第2列开始，改为 2:2:end 即可
q_est_2s4_sampled = q_est_2s4(:, 2:2:end);

% 可选：移除全零列（剔除未赋值的无效列）
q_est_2s4_sampled = q_est_2s4_sampled(:, any(q_est_2s4_sampled, 1));

end