% function quaternion = HR_RK(angle_increment, updatetime, anglur_coff)
%     % 假设iter_number是已定义的全局变量或常量
%     global iter_number;
% 
%     g0 = [0, 0, 0];
%     % 提取子矩阵，MATLAB索引从1开始，对应C++的block<3,4>(1,0)
%     anglur_coff = anglur_coff(2:4, 1:4);
% 
%     high_interval = updatetime / iter_number;
%     h1 = zeros(1,3);
%     h2 = zeros(1,3);
%     h3 = zeros(1,3);
%     h4 = zeros(1,3);
%     start_time = 0;
%     middle_time = 0;
%     end_time = 0;
% 
%     for i = 1:4
%         start_time = high_interval * (i-1);  % MATLAB循环从1开始
%         middle_time = start_time + 0.5 * high_interval;
%         end_time = high_interval * i;
% 
%         h1 = Gibbs_Dot(anglur_coff * Time(start_time), g0);
%         h2 = Gibbs_Dot(anglur_coff * Time(middle_time), g0 + 0.5 * high_interval * h1);
%         h3 = Gibbs_Dot(anglur_coff * Time(middle_time), g0 + 0.5 * high_interval * h2);
%         h4 = Gibbs_Dot(anglur_coff * Time(end_time), g0 + high_interval * h3);
% 
%         g0 = g0 + high_interval * (h1 + 2*h2 + 2*h3 + h4) / 6.0;
%     end
% 
%     quaternion = Gibbs2Quaternion(g0);
% end

function hr_rk = HR_RK(theta,q_true,iter)

%   此处显示详细说明
global N;
hr_rk = zeros(4,(N-1)/4);
angle_increment_matrix = zeros(3, 4);
t_coff = zeros(4, 4);

% 计算时间系数矩阵
for n=1:(N-1)/4
    result=[1;0;0;0];
    start_time=0;
    for l = 1:4
        t_sample_start = start_time + (l-1)*0.01;
        t_sample_end = start_time + l*0.01;
        for m = 1:4
            coff_temp = 4 - m + 1; % MATLAB 索引从 1 开始
            t_coff(m, l) = (t_sample_end^coff_temp - t_sample_start^coff_temp) / coff_temp;
        end
        angle_increment_matrix(:, l) = theta(:,4*n-4+l);
    end
    t_coff_inv = inv(t_coff);
    anglur_coff =  angle_increment_matrix*t_coff_inv;

    g0 = [0; 0; 0];
    high_interval = 0.04/iter;
    h1 = zeros(1,3);
    h2 = zeros(1,3);
    h3 = zeros(1,3);
    h4 = zeros(1,3);
    start_time = 0;
    middle_time = 0;
    end_time = 0;
    
    for i = 1:iter
        start_time = high_interval * (i-1);  % MATLAB循环从1开始
        middle_time = start_time + 0.5 * high_interval;
        end_time = high_interval * i;
        
        h1 = Gibbs_Dot2(anglur_coff * Time(start_time), g0);
        h2 = Gibbs_Dot2(anglur_coff * Time(middle_time), g0 + 0.5 * high_interval * h1);
        h3 = Gibbs_Dot2(anglur_coff * Time(middle_time), g0 + 0.5 * high_interval * h2);
        h4 = Gibbs_Dot2(anglur_coff * Time(end_time), g0 + high_interval * h3);
        
        g0 = g0 + high_interval * (h1 + 2*h2 + 2*h3 + h4) / 6.0;
    end
    
    result = [1;g0]/sqrt(1+norm(g0)^2);
    if n==1
        hr_rk(:,n)=quatmultiply(q_true(:,1)',result')';
    else
        hr_rk(:,n)=quatmultiply(hr_rk(:,n-1)',result')';
    end
end

end