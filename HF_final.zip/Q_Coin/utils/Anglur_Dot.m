function result = Anglur_Dot(n)
    result=zeros(8,1);
    if n>=8
        result=result;
    else
        result(8-n,1)= Factorial(n);
    end
end
