function time_vector = Time(t)
    % 生成时间向量 [t^3, t^2, t, 1]
    time_vector = [t^3; t^2; t; 1];
end