function result = Quaternion_Dot(P, anglur_coff, k)
    result = zeros(4, 1); % 初始化四元数结果为0
    for i = 0:k-1 % 循环 k 次 (i从0到k-1)
        % 计算组合数 C(k-1, i)
        comb = nchoosek(k-1, i);

        % 调用Anglur_Dot 函数
        anglur_dot_val = Anglur_Dot(k-1 - i);
        % 矩阵乘法: anglur_coff * anglur_dot_val
        temp = anglur_coff * anglur_dot_val;
        
        % 四元数乘法: P[i] * temp (MATLAB索引从1开始)
        quat_multi = quatmultiply(P{i+1}', temp')';
        % 累加结果
        result = result + comb * quat_multi;
    end
    result = 0.5 * result; % 最终结果乘以0.5
end